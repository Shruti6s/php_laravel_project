<?php

require_once('config.php');

$db = new Db();

$res = $db->query("SELECT id,name,age,mobile FROM records");

$header = $db->query("SELECT UCASE(`COLUMN_NAME`) 

FROM `INFORMATION_SCHEMA`.`COLUMNS` 

WHERE `TABLE_SCHEMA`='tutorials' 

AND `TABLE_NAME`='records'

and `COLUMN_NAME` in ('id','name','age','mobile')");

require_once('fpdf/fpdf.php');

$pdf = new FPDF();

$pdf->AddPage();

$pdf->SetFont('helvetica','B',17);

foreach($header as $heading) {

foreach($heading as $column_heading)

$pdf->Cell(45,12,$column_heading,1);

}

foreach($res as $row) {

$pdf->Ln();

foreach($row as $column)

$pdf->Cell(45,12,$column,1);

}

$pdf->Output();

?>