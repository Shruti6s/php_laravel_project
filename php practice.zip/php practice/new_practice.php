<?php

$d=date("d M Y D");
echo "today date is $d";
// website : php.manual date manual
?>

<?php

echo "<br>";
//associative array(key value)
$color_fav = array(
'parth' => 'data scientist & backend developer',
'shruti' => 'autocad',
'aayush' => 'frontend',                  
'foram' => 'hacking',
7 => 'UNKNOWN');

    echo $color_fav['parth']."<br>";
    echo $color_fav['foram']."<br>";
    echo $color_fav['aayush']."<br>";
    echo $color_fav['shruti']."<br>";
    echo $color_fav[7]."<br>";  //it is allow to use integer and give them key
print_r($color_fav);
foreach ($color_fav as $key => $value) {
    echo "<br>$key's favorite stream is $value";
}

//multidimensional array 2d

$i=0; $j=0;
$newarray=array(
array(1,2,3,4),
array(5,6,7,8),
array(9,0,1,2));

echo "<br>";

for ($i=0; $i < 3; $i++) 
{ 
    for($j=0; $j< 4; $j++)
    {
    echo "&nbsp;".$newarray[$i][$j];
}
echo "<br>";
}

//global variable and scope

//if in function any variable declared so this value only for function 
//if out of function any variable declared so this value is global

$m=100;
$n=200;
function f()
{
    global $m, $n;
    // $m=100; $n=200;
    echo "<br>".$m."and".$n;
}

f();
echo $m."and".$n."<br>";
echo "<br>";
echo var_dump($GLOBALS);

?>




