<?php
// echo "<pre>";
// print_r($_GET);
// echo "</pre>";
// for checking field

// echo "user name =".$_GET['user_name'];
// echo "<br>";
// echo "user age =".$_GET['user_age'];

echo "user name =".$_POST['user_name'];
echo "<br>";
echo "user age =".$_POST['user_age'];

// echo "<pre>";
// print_r($_SERVER); //additional information about server
// echo $_SERVER['QUERY_STRING']; //query string is get from server information
// echo "</pre>";


//post not show information in url
//get show information in url (for search bar)
?>