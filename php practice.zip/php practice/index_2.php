<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tutorial</title>
</head>
<body>
    <h2>
        <p>
            this is my first php website
        </p>
    </h2>
    <?php
    echo ("hellow worlds");
    $a = 5;
    echo ($a);
    
    ?>
</body>
</html> -->

<?php
$a = 49;
$b =45;

//simple if else 

if($a> 50)
{
    echo "$a is greater than 50";
}
else {
    echo "$b less than $a ";
}
echo "<br>";


//maximum among 3 using nested if else

$a=10;
$b=30;
$c=40;

if($a > $b)
{
    if($a> $c)
    echo "$a is gretest among them";
}

elseif($b > $c) 
{
    if($b>$a) 
    echo "$b is greatest among them";
}
else {
    echo "$c is gretest among them";
}
echo  "<br>";

//switch case in php calculator in switch case
$a=10;
$b=20;
$case=2;
$d=$a+$b;
$v=$a-$b;
switch($case){
    case 1:
        echo "$d";
        break;
    case 2:
        echo "$v";
        break; 
}
echo "<br>";

//all loops  

$i=1;
while ($i<=10)
{
    echo $i;
    //echo "<br>";
    if($i==6)
    {
        break;
    }
    $i++;
}

echo "<br>";

for ($i=1; $i <= 50; $i++) { 
    echo $i;
    echo "&nbsp;&nbsp;";
}

echo "<br>";

$i=1;
do {
    echo "$i&nbsp;&nbsp;";
    $i++;
} while($i<=10);

echo "<br>";

//loops with array

$collection_of_fruits = array("Banana","Apple","Mango","Pineapple");
for ($i=0; $i < count($collection_of_fruits); $i++)
{ 
    echo "$collection_of_fruits[$i]<br>";
}

echo "<br>";

//better way to use foreach loop

foreach ($collection_of_fruits as $value) {
    //$key is for object no need for array 
    echo "$value<br>";
}

//functions in php
function marks($x)
{
    $sum=0;
    $i=0;
    foreach ($x as $value)
    {
        $sum+=$value;
        $i++;
    }
    return $sum/$i;
} 

$student1 = [100,99,95,54,62];
$student2 = [100,50,80,54,62];
$student3 = [100,89,25,54,52];

echo "this is function calling <br>";
$sum=marks($student1);
echo "$sum<br>";
$sum=marks($student2);
echo "$sum<br>";
$sum=marks($student3);
echo "$sum<br>";






?>


