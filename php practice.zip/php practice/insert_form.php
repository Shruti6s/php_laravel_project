<?php 
include ("connection.php");
error_reporting(0);
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>data inserting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
      .bg{
        width: 100%;
        background-image: linear-gradient(to bottom right, yellow, pink , blue);
      }
      h1{
        color: red;
        text-align: center;
        }
    </style>
</head>
  <body class="bg">
    <h1>Marks Details</h1>
    <div class="d1">
      <div class="container mt-3">
  <form  >
    
    <div class="mb-3">
      <label for="num" class="form-label">No.</label>
      <input name="num" type="number" class="form-control" id="exampleInputPassword1" required>
    </div>

  <div class="mb-3">
    <label  class="form-label">Enter Full Name</label>
    <input name="name" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required>
  </div>

  
  <div class="mb-3">
    <label class="form-label">Enter Subject Name</label>
    <select name="subject" type="text" class="form-select" aria-label="Default select example" required>
    <option selected>---</option>
    <option value="Fundamenta Of Computer Engineering">Fundamenta Of Computer Engineering</option>
    <option value="Vector Calculus">Vector Calculus</option>
    <option value="Fundamenta Of Web Designing">Fundamenta Of Web Designing</option>
    </select>
  </div>


  <div class="mb-3">
    <label  class="form-label">Enter Subject marks</label>
    <input name="marks" type="number" class="form-control" id="exampleInputPassword1" required>
  </div>



  <button name="submit" type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
  </body>
  </html>
  
<?php  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$no= $_GET['num'];
$name= $_GET['name'];
$subject=$_GET['subject'];
$mark =$_GET['marks'];

$query = "INSERT INTO MARKS_DETAILS VALUES ('$no','$name', '$subject', '$mark')";
$data= mysqli_query($conn , $query); 
if ($data) {
  echo "Data inserted succesfully";
}
else{
  echo "Data not inserted";
}
}
?>
