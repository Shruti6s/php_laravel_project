<?php

//associative array has key value as index 
//indexed array has index value only
{
$age =[
    "parth"=>19,
    "new2"=>19,
    "new"=>18,
];

echo "<pre>";
print_r($age);
echo "<pre>";
}

//------------------------------------------------------

// video-33: yahoo baba 
//indexed array
$color=["red","green","blue"];

foreach ($color as $value) {
    echo $value."<br>";
}

//associative array
$color2=["red"=>1,"green"=>2,"blue"=>3];
foreach ($color2 as $key => $value) {
    echo $key."=".$value."<br>";
}

//------------------------------------------------------

// video-34 yahoo baba
// multidiamentional array
$emp=
[
    [1,"parth","data scientist",500000],
    [2,"other","new skill",100000],
]; 

foreach ($emp as $value) {
    foreach ($value as $value2) {
        echo $value2." ";
    }
    echo "<br>";
}
echo "<pre>";
print_r($emp);
echo "<pre>";

//------------------------------------------------------

// video-35 yahoo baba
// associative multidiametional array
$mark=
[
"parth"=>["physics"=>99,"chemistry"=>99,"maths"=>100],
"other"=>["physics"=>80,"chemistry"=>99,"maths"=>80],
];

foreach ($mark as $key => $value) {
    echo $key." ";
    foreach($value as $value2)
    {
        echo $value2." ";
    }
    echo "<br>";

};

//-----------------------------------------------------

// video-37 yahoo baba
//foreach with list
$array=[
    [1,2],[3,4]
];

foreach ($array as list($a,$b)) {
    echo $a." ".$b."<br>";
}

$emp=
[
    [1,"parth","yellow",7],
    [2,"other","color",0]
];
echo "<table border='1px' cellspacing='0px' cellpadding='5px'>
      <tr align='center'>
      <th>No.</th>
      <th>Name</th>
      <th>Color</th>
      <th>Roll No.</th>
      </tr>
";

foreach ($emp as list($no,$name,$color,$roll_no))
{
    echo "
    <tr align='center'>
    <td>$no</td>
    <td>$name</td>
    <td>$color</td>
    <td>$roll_no</td>
    </tr>";
}
echo "</table>";

//-------------------------------------------------------

$a=["hi","hellow","world","name"];
echo count($a);
echo sizeof($a);

//-------------------------------------------------------

$a=["hi","hellow","world","name"];
echo in_array('world',$a);

//-------------------------------------------------------

// opening php echo $_SERVER['PHP_SELF']; closing
//  use this in action attribute and information get in current page


?>
