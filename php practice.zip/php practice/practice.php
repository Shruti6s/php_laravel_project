<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Canteen Management System</title>
</head>
<body>
<?php
    $s = "hellow world";
    echo (strlen($s)."<br>");
    echo (strrev($s)."<br>");
    echo (str_word_count($s)."<br>");
    echo ("hellow");
?>    
</body>
</html>
