<?php
$servername="localhost";
$username="root";
$password=""; 
$database="parth";

$conn = mysqli_connect($servername,$username,$password,$database);
if (!$conn) {
    die("we fail to connect".mysqli_connect_error());
}
else {
    // echo "succesfully connected<br>";
}
?>