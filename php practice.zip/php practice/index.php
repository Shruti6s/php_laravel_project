
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Parth | Portfolio</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-onix-digital.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<!--

TemplateMo 565 Onix Digital

https://templatemo.com/tm-565-onix-digital

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <!-- <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div> -->
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="index.html" class="logo">
              <img src="https://cdn.dribbble.com/users/2306450/screenshots/4851097/media/b582f1b4efb860d5c68b8116c8190ade.jpg?compress=1&resize=400x300"  height="75">
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active">My Self</a></li>
              <li class="scroll-to-section"><a href="#Skills">Skills</a></li>
              <li class="scroll-to-section"><a href="#Certification">Certification</a></li>
              <li class="scroll-to-section"><a href="#Tutorials">Tutorials</a></li> 
              <li class="scroll-to-section"><a href="#Projects">Projects</a></li> 
              <li class="scroll-to-section">
                <div class="main-red-button-hover">
                  <a href="#contact">Contact Me Now</a>
                </div>
              </li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->


  <!-- top introduction part -->

  <div class="main-banner" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="owl-carousel owl-banner">
                <div class="item header-text">
                  <h6>Welcome</h6>
                  <h2>Hi<em>&nbsp; &nbsp; i am Parth</em></h2>
                  <br>
                  <h4><span>Your desire is our challenge</span></h4>
                  <!-- <p>This is a professional looking HTML Bootstrap 5 website template brought to you by TemplateMo website.</p> -->
                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>My self</h6>
                  <h2><em>My name is Parth Nagariya</em></h2>
                  <br>
                  <h4><span>I am a student</span></h4>
                  <h4><span>Currently I persueuing B.tech</span></h4>
                  <h4><span>Information Technology</span></h4>
                  <!-- <p>This is a professional looking HTML Bootstrap 5 website template brought to you by TemplateMo website.</p> -->
                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>Academic</h6>
                  <h2><em>I am in 2nd year</em></h2>
                  <br>

                  <h4><span>I am an enthusiastic in CodeTech.</span></h4>
                  <h4><span>I like to work on python.</span></h4>

                  <!-- <h4><span>Currently I persueuing B.tech</span></h4> -->
                  <!-- <h4><span>Information Technology</span></h4> -->
                  <!-- <p>This is a professional looking HTML Bootstrap 5 website template brought to you by TemplateMo website.</p> -->
                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>Personal Details</h6>
                  <h4><span>Birth date      : 01/12/2002</span></h4>
                  <h4><span>Age             : 20</span></h4>
                  <h4><span>City            : Rajkot</span></h4>
                  <h4><span>State           : Gujarat</span></h4>
                  <h4><span>University      : RK University Tramba</span></h4>
                  <h4><span>Graduation year : 2025</span></h4>

                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>What i done</h6>
                  <h4><span>1. C</span></h4>
                  <h4><span>2. Python</span></h4>
                  <h4><span>3. HTML</span></h4>
                  <h4><span>4. Css</span></h4>
                  <h4><span>5. Boostrap</span></h4>
                  <h4><span>6. Photoshop</span></h4>
                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
                <div class="item header-text">
                  <h6>On going learning</h6>
                  <h4><span>1. JavaScript</span></h4>
                  <h4><span>2. Python For Data Science</span></h4>
                  <h4><span>3. jquery Framework</span></h4>
                  <h4><span>4. PHP</span></h4>
                  <br>
                  <div class="down-buttons">
                    <div class="main-blue-button-hover">
                      <a href="#contact">Message Me Now</a>
                    </div>
                    <div class="call-button">
                      <a href="#"><i class="fa fa-phone"></i> +91 7016926267</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Skill portion  -->

  <div id="Skills" class="our-services section">
    <div class="services-right-dec">
      <img src="assets/images/services-right-dec.png" alt="">
    </div>
    <div class="container">
      <div class="services-left-dec">
        <img src="assets/images/services-left-dec.png" alt="">
      </div>
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2><em>Skills <span>Set</span></em> &nbsp;I acquired </h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-services">
            <div class="item first-item">
              <div class="icon_font">
                C language
              </div>
              <div class="icon ">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAyVBMVEX///9ca8AoNZM5SatUZL6ttNwtP6haab9dbMGgpc9WZr5RYr0mM5JXZ784SKsbK48hL5ETJY73+Pzu7/j09fsWJ45qd8SZotYLIY3Y2+6BjM0AHYw3Q5rn6fVjccJ8h8ve4PGBh7tKXLubo9bKzulNW7IlOaZ1gcmXnMZYYae3utdgaKvLzeJGUJ93frZtdLFPWKOrsdzDyOaNl9JIVq4vO5bBw9uqrdC8weJzfL5CUa+IktApPKeRmtKss91td78AEoqJj748R5tWklaYAAALz0lEQVR4nO2daXuaTBSGq8EOsoRdQUVxSYxrltbE1tc2yf//US/EbCowZ2CGMb14vvRDL2FumXPOnAXz7VupUqVKlSpVqlSpUqVKfTF5wy6qoMZtwHshjOQ1BhKKJA16Ae/FMJDfGqDKm9TB1uK9IMqyhrJa+SxJvjV5L4qizFpFqBwICd0173VR011DRoeAEaM8nvNeGhV541i+HWPL57283LI2Bwa4L1Vo2ryXmEvmUJZS+KLHKMk13qvMobV65GBiGAXxjvdCM2oU72DizHHs8V5sBgWfIzyWcfDjq7kcqymkOZhjSdLwK7kc8xZhHEzMYxTEr+Ny1l0BvkE/McqNEe+lg+RBHUwc4zjgvXysfBIHE8M4+HHaSYd9mEKQ66STDrOGABEeq9NNOsARHick/z1Fl+P1KPHtGFsBb6AD+VvCCI+TKjVPyuUMJeIIjxOSpD+8sd61ljNFeCyjoJ5G0kHNwcQwyg3+SUfQYsb3wjjY8E06rGbuCI+TJAz5uZwsKQS5oqSD0yknoUjIgJFP0pFSJGTB2Cva5VhsHcyxVHlTpDmazUEGB4M+KwPjYFiYOdYEMgeDkCoJsoTEbmOnrogkWZBIQQWhmKSDLMKjkEVt9Jq1UeBbb8/AtPxgVGv2GmrITXKxIlyOR2KAIR3qDUd+0u6y/dGwh0JKAkbGSQdJChHidbd3ePdgjZpdAkhVYNhcNesq2ACRrDZHUM9gekMVvjUkxKrOsRbBKYQ6GK/JVmHejQfQry885bBwOXOwgwm35ybIcAd/C96sDJIOvwctEoaZa+bs3GpKYMYB1eaqDY/wqpTLEVhbCXynAbXmqlkDOxgKzjzYgK1dUukkHQQphNClEZBHDWjVNTTH/HUOkhRCptQgs4fge+ZurvrpcwZ7khA99+bBU2tVyONyCLoQSN7QDMPmBr51VLme8S4+PMKHgLTbm2s4IhIamczDr8BzQFWkn4J7XYL7N7JsoDH8BtJfFiU/aww0RlEUzn+RX38tgwGFFpshA7MFChsi+n1+dkl+Uu3Cg8SGAd1OG/zXLKKfZ+dnZ+cXpNf2wI9Q/sGC7VU/MMsQxYuznS5JDaUGPVcwBcQhikK4QXf674HwylBCgd0W3WmTvJAXA3zTd9KgCCSUWkywPquV4FHFys/zD0BWhGq2UEskMzZsiZWLsz2xIUTdIlpf/rFbDyPg2XkBhEguppngHR7gROn3AR8jwsKme2t7DjV0MIcPkBGhxNqNfmjz4W0+IiBzQoSK61ua77V/UYp5fowICzLCnV6PWHsRkDWhMGSCkqShcBQBGROibrFDy3YYMuINkBWhUHRnfTRIMEBGhGqm05rlB57nBX6GmrHdTN6gLAiRFJCu0LttNbpIkGVZULuN1q1HtMtrv7+n8lEnlLZEFzPvWhVBUN+62uG/qiBUWnfQcONd/Jf+AKkTIonkPGo1JVk9rhggVZZA407W30ssH21CqUnAtx0k9pOQhH9b1hxe4jYoA0IZ7CrMWzndZUnyn9S9uj77DniAtAlVcOEiwHd1Upud8wpkg9InHATQi4CagaqUkKP4v8B8dAnRGHiNLfjtvDjXHEZAkAEyIJSBPbse/OULoXe8AGwEZEaIVFgYg9bkXyQd7Is5IAIyI5RgSUWPbPZN+vwUYRGQGSEsL9ySvh8kvNuiDYyArAhRF7JJa/C+zvs39+pR17+BEZAVIeg8ExAM471/dS+n+VGXfINSJpQBiaHZyDLBr47JIiAjQoQAJ7Zb8j0aSpQbRBGQFeFx5DqSlWUGPCoyYZLcYgghsWJL/haGKP5ML1IURwgwQ39AzneRk48eIVLxue+Q9BHGtSH4EeLHOkzCV/VeDDA3IDVCFe9o7ohOM2LlZ346moSAeN8iiIU0DJAyoYBtqNkV+CalYoCUCfGu1ANvUkoGSJkQXwm+BRKmtln4ESKEDRYwM6RogJQJReyptAExQ5oGSJkQmxxagHk4ugZImbCB+5wfU78/4KMVATkRBhhHQ98AiybEzDQyMMCTIhQrDAzwhAhDA6wq1dVXJ0y0w9AAV0o10jkTQ+TuS0Wps+PbMZ4uYcZ4KKJog36IwVbleqbZGeC+Vqd6pslwLv0wwAPGkyTMkFvsGeC+qLocXvlheATVE/gi0QPklOPHGeDRczwxQpI6TZIBsjFHatVEQK1NxhogC0Z69VLsOJr50lkLDRC3QekyFlrzFqI2BJwvUn63WmTfwhpEBkgEWM3vcqgRQoaft2TP700nQgjpH/puJsLwJJepg0+bENIDvjIyERpXtWxTClQJQRNR5iLtIJMkfWF+s7dZn2PBsxieQ75PFe1lUMdvfc/UzC96nqbuEhO6b0v0MkxEcZiJWpKaorH8+PDo4pInIXAEeuIQATqT/dt/JzVHDrOJNySIzs3hx4eEjDzmSyfwjWpMjj9ubYhcDpcZ4SUw8ivuMvbzwS+CIVM+c94PDiQu6lri4ubwOT5Os/rewsA9RsVYpDnnNXRYmNv7FleulgqouVfpjsu8hY3z0SUUCN6Z8ZePyYza4xKfb9pbyMwwz/ee/L5j6MebVdENpw+7jgUYO+X87tp0phiOrr+mxYqi646hzKbwV6W9Ls4c6RKK0jnpa872/Gq2WGmG23YNbbWYXc0J37IdXRT3hmVUBdVmhNd7kRW9Qup5QabfHbxWCiJ8rYK60yyrzKGpkV6To0UovlVB9U7B73Lvbptck6NEKKLOWxHN6TMhSVL/7RzPlHC/Ctou8g9Qztvv903oPFIgDA1wr0qo6MXtU1v7dGcl1hxzE4YGeFjlzeZPM2l2cCyKYcxLGBng0amknfUXGUlVbx/dm/Iv8CT0ARW3GFOcx+aZFH9FKbkPqKwK+Z2ohLuvKBGm9jn1BXtvYyeXlz+7VWLCP0KKAX5IiymwUNYkLcFc5SUMIyCmTeawdqgzTMnuPM8uPYyAsTKumYC96RpfsNud5Ih/N9EfiMA+J1NEAGB113kk/u3Lb2MBOGhQNdhtVBhgxHjeJb54fBCKlTNh41FteGdAMTKE5j68faQtWMRFf5Fepvss9ynDDcwZvCqvV+mfbuYreJs1q6EsH8EbVXFpn1HrLhhQb8d3BQCaP2NL1h+IM5rGaM/a4DsbnTwb6GEF7ldrDr2dOtehJqg4K9JAeCD7StGAjEq7T+lvI/ShD1DR9Kf89/SXBtQinA6NCty0Aw0SugtoCkDkgY1CcSd5fxHTm0G/UKU9oWcX9x1ocNSdXF+rv9SAFqgYK7ol2wcH6HIULTuj39eARq9oRp32D8TafRd8d/c6y14NrqF3iCIgi4OiP4MGYUVvLx4I/2bX9KYN5jNmAQO+SHN80/od0nD69+C/uzbvO+AjjGIsWBbAph0wY1VzV8sp3iT9aX/VBp+xwxNMzgiPU3gCgE/lhRapTfpTP8lmbP/+aaKBrS/61vQr9rUvf9kmma3UQ4LOpF+/94J3UtsPvPt6f/Ic/l9M/zv5Wm1KER6nYAI+Fr9IUXTNcR29uuo8Py+enzurMGy6jqaTDYMr7ZvifmD7fgU3x0+gkfTdP+SfNqr3hfFFelDIZg9zSnH0opok77KfoOcPCtI0SmkLmfxreBqeS7p7HXDgizS/KYBRcW+K7DYfavqc7cUDuAwqOWcOmXVoupNJmlNAhMfJ6j+y2qr647LIP6ierOAm42tAGD53EvBGe9c9vOwIlWI8FxvhcXroZHhNJkW5i4T0ZT+Ba5x4adrTaRjgvvwlpeiot6+LSSHINSdMOmIVphA8IzxOJDWAeD7aRUL6qoMLSnF8Whszun8KMsFlxyPpLpMiIX0F4ML8Ph+7IiF93d8Qm6NiLE4rwuP00CFKOtgXCenLvnLgJwDNPYEUglzgsmNhRUL68m4AJ4BCi4T0dY87AXyBCI9TXU8pO/IoEtKXlVh2VDStf4opBLmC69gTgG5kaqSepuaTozoH5yIhfR0kHaGD+XIRHqe9N4K/RApBLmv5aESdJ904lSIhfVkPs061M3v4V/lKlSpVqlSpUqVKlSr1D+t/3SNJnn5smEYAAAAASUVORK5CYII=" alt="">
              </div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-success" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>
              </div>
            </div>

            <div class="item">
              <div class="icon_font">
                HTML5
              </div>
              <div class="icon "><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAsVBMVEX////kTSbhNQD7497kSyLjRxzlWz3jQAj1x8Dqg3LiPQD/+vjiPxH0wrnjSiHiRRjpemX+9PH/+/nnaU/wq5/qZUbri3v87uv3rp/tblL7wrf0kn77uKvqSRn/6eT93dfxd1zziHP/zsXtWDL6n4z1opL1g2rtUCT908vzel/7s6XuY0H93tfvaUv81s7zu7P5k37lVDPtlITodF3gJgDytKvskYDvopXpeWPlWz7riHfE1GTcAAAM9UlEQVR4nO1da1vivBa1pZliiK3loqJcRkXBQQXF0Zn5/z/stBQo3ZC2WWlpzyvrw8gIT+wiyc7alyQnJ0ccccQRRxxxxBFHHBGg6Q3vZlej+e35ohtgcX47H13N7oZes+xH04b3fP3w2BlzbgvhMsacEP4rVwib83Hn8eH62Sv7MUHUejedPrdd5hhyOMy1eb9z06uV/biKGPQex1wkcovzFHz82BuU/dhZMRkF7KyM7NawApajSdkPn47JvM9dVXYbli7vzytNcjiyOAPZrcG4NRqWTWQ/Gr0p3nukJ6e9Rtl0djC46YushiUdjujfVMvuDJ/MXLovguWaT9UZrJMuz6/7IjDerYbVeS2GXwCHd1/LpndSeyqMX8jxqVy14821V4c0MD4vUbf+4m7B/AK4/FdJ/IZT+wD8AtjTMsxqc1ToBIzD4aODu5Kv9+Jg/AKI+wNb1UN2YAi/Gw/IbzA9bAeGENODCbnrg3dgCIdfH4bgnJfCLwCfH4Cf91LGCF1DvBS+/A/HRYuYZLBxwUtjWVMwQsGT8cosmV8A86o4gqPybMw2ilsZbw+lQ9Ng3xZD8LFMIxqHeCyC4M/qEPQp/vyPEyyCYoWGaIi8B+pt1Qj6FHM1N6OqWNFt2DkuGlfVWAcpeG5L/3UVlMw+mDkJuOdq9mAA/pwHQW9cttiWwxnn4Uy9lOsuJYO96BO8UVgnLFf4WH4jTvBKWKufEQxj+RkRhpJX764/BgwWcaNL8FplErqXzUbj5Mynwf6dNPyXLfEe/NyCadeX77wHFK03//ONZsNh58tf/gOGi667OFCyMmI5K87sJcMALfFAGjR5PXwR5BvNMAbaZD7DABfIhOB6Ebip0sBRYVg3jRWvk4YWQ2eqQ3CkJtZUGJ4smOnlwdAQGtrmVXElDBnOTCH4aSrDy4/2SS4MDQ4H/Jv3isYtZDj8arfbZyFD9/xsNpuF4bFZAHvD8OT3+oUuQ+ceTdsojtE1wy20HGbbthl2lum/FEbEcANdhvA4HSqrtT0Mg1+7IcNwCSyCocGxIKqaHVVjeLn6wGU+DDF7+kvdJ8zOcBj+qvaVD0PDBhLhHuBRZGdY+1h+1GjHGJ6afAmg+IirS/AboAhhtR4ab29vFykMzYX/b9uMM/Qul/B+qFN0lfVpDXEKVwy5ZbmnKQw5PzsZmCLOcA2AocFV626ekCmxq2nkDC23uWA5MmRPagRV1Yw6Q8N5c40cGaoqmy7k14tGBoaTFUPDpyFCXZMLQ9ZVITjBQjNsduYjcP2cRd1/Ve8sH5VdBP85C7808RW8bodyafWO5bSWP1eov0GVnEqdiHWh//i+MLOXfeUEr+zVk7Llf1afce2leou/E358DaxU1VHoRHW9VgkoaDfIkJaP7OZ0UNUIcBrMrAENRM5UAlmFTaOfb1H64WD1s21i6Kln0sxioPwcopeJobpf6A5qRWCgPFuy+YnAUmFm+ubUod6JmRaMkbqdMS/TmwVwqc7Qfc/QrqFuZ8xias2G6gwtI71ZRJLyYva2FPQoc0DP2GeFMDwDqgdYegVqX73VtXuUN9qI8uintQr5TZnmtzreEYapwxSwpBt/N28g6UTDTYt/jyH3elEIwwXC0BonN6qWEd20msFGAwDWLSM1Ywpo0gDFiBrMiUvRpo+Y71slhiy5pA+ahgXJNkC0BUieiFCkO2CYS20SwTMYakiMfoPTUCPPnAAsKp0yEW/QJGwRsm0Gft0sKZbRAeOkhcg2SLT5cDryNj1ElC4ZkpIL9gPAG9F+D2hArC/PJcJ1lu5FvCHbsdRB1e0FyjChJvMaLXamsq2FjHY61CHRFsCWl7rB48J6izd0ijwc9TKx/IyxO2e2ACoan6ETb+gzD7/HQRkmqBrUlPrLRbwq6QtiGF9Um/AGCLkxbY7RNg0el23QUkayDpd4AmwsqwJDCkxWIEqpjrRkxkPyqII0EkpPNIrySSQWElzEQdFIYkqXizt8Zwyxg0h+zmLxp0EibeunuZMwnOFtCrKWRQwtOyM4WXHa+FYreyZheIW36X7Fm9oaYfWsIIsFZI9DCNl2ISjOtmJIZFu0Wgv0XDJYtCXE25Bw9wpUtkWKC3b/YdGWEPi+xduki2wk28DiVh35YTDZ1sRznCEVpp+bpuCcBixLDYOUWEVY4N+a5cSnW+S9it+Sv5aChvLpmREcWYT6p8YmNSLbosUMzWloiDZ5dRRa6xWAGJRItklHTAp0inoKYUgMSiS5nBbGUKfyrBCGxKBE0Vxqg7JCQ7QVw5AYlEbUAxxj+Ftjf7yUoYYtpUGWZpQ3YqfZQHaaoLHEJUOZLdVYDw33M97W1nrNMsEkahnfe5Fg3TQ0jcH+kPGg2hbdLfRH52FkmkZDl+6YTOXxQPMpUEByBaku1fAtDOtvvC3lKgOq0KFq9hWkvoWGf+h76HHZpmwK7XhspaFT4yr1DzV8/J04kmpbVNg2dOqUpT6+RpwmQbZlAxUGYAI4hDROo3UABqneqyk+IXUwtbYLSGNtGvHSHWuv6hrQIAEUcd08iyxeqhHz3hn7npklvhaZI1pWpWUTpDFvncDBTm4sU3gtsrg0WKcl2uRJYDj35IN9SpuVI6qRpQHXT51Hkeee4Pxh0OwpwDCqhKTBDigDuUJC/hDOARtg9V4022wiSzViiUk5YJ3lwvoBMIzi2lSWakTakvL4cC1GAEHaGmwgL42I1CutKNQxpQm1GFrGlCTHvj7WO18+5MU2kRNIYnVg1d4SSfU0cE3UkqEsDZwQT4xmGxkBOqItsSYKrWtbMpQlSRNqpDezjZY6AFstNkisa9PILNNSilqWeOLmM1R4gxuRwwdJ3JkP1pcGoPHE6Old6Z/b9BRdazRiiSmF3hqqhsq2aMBLK4i9DUOXjGQN0ZZSI6wxEalBsTbDwZRZ78jFojIE2moRIqXOG6vVX4KRNPDfzcpjyiZG5ARS4Q1ttQiRdroZPhHpVIqibex0ss+dadQj8UllKS7a0vZbaMTbqDncGmiMm4t2vCNr7YW5dQsPlaXYVosAqXtmNMw0SVDEaymYMN8+6+GE9OoXb6aI9RLNhePLYfr2PFyaEpO5U9tmudxutYftls138rt0quIMU/euaQS+iWzbW/nFBN97wiUxt7hoy7D/EB+mZNOF0nYJ0v+qkboIWbazwpOc1Icq9QOZw+hWi2x7zODFltaVKDCkdvgMFR6Z6iLgWCyVbR92xiltuSZx6WDRlq0+Sf1MhRBUeXln/2zTTWPpLyPuZ50Uv6EhsYxn76HalKaBA9TafwR3ZV+Z43Jx/nuPykKr9jKei4GebSKLtr1+dezdO1iD1bHzJRlUoGjLerYJej5NQrTNq7//MO1onfeH5o+1wtkHMNKW+eA9sByJRiIILmenbjAtHde09w7NLYBbLTKfMYSeEyVSG35utz5asqEZAdxqoXDsHrhg0IggDLBqT6WUFauOUj6cUQYsIKZyXhuomuByYApsDKlt1e3msfkMBhRpUzs3EetEtBx4B9BWC9Xd1og5peEkGMhWC9XzS6HJvk+2QUBEm7qZA4RNbkecAKJN/RxhpPQkMa2lAiDJB5wFjZznzf6kqLEsqP0GuhA5zxvyE31Fzd6ps6eARv1CpLuUuwDvuMDWXd8rMltt5CSQ4Vdr2/9QAao1lO9GWMPvSuN0pqJSL2fnjin1lNMA3+GhfL/FFixm879fmRbhxuT9Bwc7bwn8fgs8qLf6y74bn2Z7au3FngCAGnTOjoHH6QaB7dkJNK3g1S8yhKpSoXPPDB5328Z+26NhV+LQuytIJ2MaA3O3bY9vVxhuVwg073tSu7MrESvb403eg9RabkcV61/xrHLvWir8Act17Uoc+veufYO7877B/Yf//Tssv8E9pN/gLtlvcB/wN7jT+Rvcy/0N7lavGMUiCFZqoOY/REPcVsWi2jkbmQijaqyLPNdlIo6rKqgbM8eFfhfXvGwZ7ug7hMkYjst1pti4mLs0tuC9lGlSxUsu7lIK5uXZG55ePZoLypqMhU/BCINpGSNVTPUTW9kxOng3OkWugvvwen/YbhT3RRz7nojmIbvR70A4+aKB4fRQOtWeFr4ISvCLH+IeQZdDKex84M150RKH8fkhFnk5ak+FTkeHP+VVDojjtVsYR4d3D25B92LSLWSsMt4t5j43BMMnM9eM0nIPxlNZBnQ/Bjf9vVu2MDiif3NIiZYNjd40n9Sg5fJpD686KhTDkaE9Ixk3RtUangSTeR/vSb/3+vPqWBcpJqMxV0/UW0zw8ej/gF6IQe8xYJnV9DgBu8de9WxLMmq9m06f224iT4e5Nu93bnrlKxcM3vP1w2NnzLkthMsYc0L4r1whbM7HnceH6+dydWceaHrDu9nVaH57vugGWJzfzkdXs7uhV4bTd8QRRxxxxBFHHHFEFfE/1NYoKc6xQP8AAAAASUVORK5CYII=" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-success" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100">95%</div>
              </div>
            </div>
            <div class="item ">
              <div class="icon_font">
                Css
              </div>
              <div class="icon"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAaVBMVEU3mtb///8qltWiyukfk9MmldQwmNXj7vhTpdqsz+qJvOMYkdPe7vpOpt09nNdZrOGOw+l3tODx+f/L5Phlrt+93POz1vDY6/lwsd/q9PzI3/GbyetuteV7tuCn0fDQ5/e21e3B2u+QweUKVQEKAAAMpElEQVR4nO2d6ZaqOhCFFUMcEEXbdjg2re37P+QN2gopEkh2BYfb7l9nsU4rn4SaUkl6/f+7eo++gc71Jnx9vQlfX2/C19eb8PX1Jgyi5fTj+L3P8u1qXmi1zbP99/FjurzHl3dMOP3cL9IoEXEcR7KqSF0RSZQu9p/Tbm+hO8LhOkuFUGC9JilUIdJsPezsProh3K0XUsTNbBpnLORivevkXjogPGSzJJbueL+QMk5m2SH87YQm/JhEIvKEK6X+dvIR+I6CEk4zKbwfHn2UQmZBbU9AwnUqWsyKI2Qk0nW42wpFuMuECIH3CylEFsruhCHcfCX4y2dWlHxtgtxbCMLDPODjKyXFPIRp5RNuuuH7ZeQ/Ry7hcNUZ34VxxY12eITLSdIl35kxmfACdBbhOg5tX0yKYpbvYBBOU4/IkyMZp4wYACfMOh+gFcYkuzvhZhbfja9QPEOtKkiYJXflK4Q+Rohwl973AV4Up1AghxB+duoC7ZLi8z6EE/EQvkJicgfC5UNG6FVx6u3+fQmnzAyXKyl9XaMn4efjRuhVvi+jH+H3/Z1EXcl3d4QP8IIm+XlGH8L88UP0IpF3Q/j1SCOqK/7qgvCJAL0QnQmfCtAH0ZXwyQA9EB0J82cDVIiO5saNMHsWK1qVcHMaToRP4ejrcnP9LoRPEKqZ5RTAORBOnxVQITqE4e2Ey3tUDFFF7clUO2H62HSpWTLlE04wPxFVdbkZ7ZK0/C9fxa1ZfxshaGVW44rWZ8B0Xb02OiNql1bQN7VamxbCHQYoT9qnzBSOHGmX8uLSTLt0wl4H0VKBayEEX0Kpjx0D4aJOOAG/q+VVbCbMwGDtnoS9uDm2aSTcoLHMXQl7SWPBv5FwBn6lA6HhPYQJe/rneBCiY/RGeNwuCuWXi1fnfFJX8/MLHl2NxOB2CVLjOG0ghMfojXAvLo2Il2vyirgSv9dkvKOXMDWN0wZCRjBzJdS9uLzxXK/L+DpLv2UloE321E44ZnynhTCqI4owiPHYn3DJyShuo1SP2uLkxnO5Vly6pge8MoKwhuBWwgknpfgl/Dc4a3y+NBsX/75+/Ki4dr60v15acUL8yBqf2giHrKTwzt6ikLD13dgIWT/onT3+5StXfoQbXl7/AMKesHgMC+Gc2Qf7AEI59yE8MEszMt8NS+0uhNql7ZlQu5QziwnC3MloJmQ+wnMLbEXS/RLnO80P0UjIfAsfJfObaCT8eubik13SOJVhItw9Z4m7XYmpoGEizJ65QtqkyJRFmQhf8y0sJNwI1/4hcNSNvO/D1GtrIEy9P1gOupG/wTPkiXVCYCImMQyOEPK3eIapmjohYGeSbhaDLv0JDbamTgjUS6yZC09ABidlO+EHYEnFv04I/yG3UlvcVyNEIvz4pxPCH6CuIWu5fo0QWWAXDeinBNEAiDxk1EYI5U1kqimUoMmoWg5FCaGITfp00rkLShhr1pQSQlMV1hoJT1itiE5iEEJsRlQ2To3AmkGEdMaUEAIxaaG4E0LwXkhsSggXWO7bTdiGpaly0UgITgDZa+oMgfMKNKzRCdFKt61WyRJaLSIxpE4IvobdhG1I0FaIvIg6YYY2Cxw7IDyibRK6R9QJ/ZPfizoJ25Cg7Sw9DdYJ0QoNCduW+ek0aVCua3HRlgx1sIOIVms0QrjPkoZtiQQkfvQPgav8eqKvEX6i07C0oA61ANCYGZ5aiLVWN41wj458GrZBgQOtFGBBm1K0r35Mj31jl7vTbw76qWjFGi7b6lGNRoia0lrYBhl6GvrhcwuaMdUI8Wo+CeihcISMA7Dxs5CW51cJgerd7e70sA35JPouM6b4tOpmlZDRlB8TX4bUkPRp8P4/vL9GcxdVwg/8M2nYNvK3WbRQgAZtxd1US4q9MJ9Jw7ZFQvU7lR31LHUSKbb6R8BBG/m9q4TfOCEtUy53u92yUJ/q0/h4pZjRzjRGa0ZcXS5UJYQdfj2xtmh3ik07vkTJtt5HgTtn3eVXCdHcqdCI3qBB/1amDV9kHJ9MJYIRfjNa/lQlZDS0OFTbxjNTP4kUqSW3hIM2kghUCbeMZ2iaX65oOEkMw1NGycJa/2DMtcuq0aoScrr1GqttPyPj8BRy0FDBYjSEaI6nSsjphLKvXFkOpHF4JqOfpl+F0/6pJXPBCC2jbZMnhtksNTwnLbOqnL6sTgjNU4jH1Gxdeva27KuQycNuCesW0eL8ZLJyqT0yAqxuCPW8WumwtWyHuXerjzOCNjshx5bSsO1k2c1NjuYjo1Iyy8rpp7XaUo4/lK5xs63SFpNBEOxmAsU0tbDN+zWia0IYQZs9puHEpXTGx9sUUmPc49yMLS5l5Ba1sM2744FWSzkNktbcgpEf1jq/vCsipCONUTNqyA85LojWc4e+d0gmWVlrdqw5PqNOw6+2kVHOaqa31mlYG2BQS+H7WaTZgRO02WttvLFPrL1wmm+6/TlNoTmrH+31UkbNux62mSMXGsiUiMSfsuy6tebNmLcwNQU6qPQpNCZiLYKyz1swylu1W3RSab3pD8QK2uxzT5yhQYvyTirfttogD5bnhJkDPn8uQFjG5xExVJzXsGEOmOUukM6vshmBOhuOWW+Yx2cFg7RhfzO9yl6RKe0JmbxiOa6GXgyWMaXT8OXCQvt2AKVpo0Ef57du6qfh5E80Obj5Omnf1aCsKpBJfM4i1saeKLSvrRB9kyp3byUc2f4PJ2hr7GvjDA5qDXMHwnJuggTeY4YtbexNRPtLz4TEo5V20l4PL0MaEpZyJvoa+0s5UQ3t/Cp9nb37tLSYJF7gTIM19wgzXkQ6D1/GK7SN4abSJ9CYj1HYbOnzZjSx0D1iygZY66KhcsExDUsZe+O09OrjW0Opu9Q/qZI3jAaGcbo8LsoBQ19ihtdqWW/BWeVMTGbFLstIiMWx+tsOxyNtypQaYjykaV0zw3C1JGwjgVdx+N/p8kIeTjN6QhsZyJzurLZ1T9Datd/PJmFb7S6lFGI+yGPD+XqkFR73y+1r1xjJtVPnlzT/gqRairbpO60/RNaQXkRNpo89JGEpHrQ5rCHFwxra+eXj04iVgicPXdYB49Y0IjOAC/f9WCQhhNv0ndZyB2vY30x6Todanq2s/qeB2vQthHAabFhnORyvTJ1Clb+pecqz4KDNaU8FODa1dH79KPdgHPjF+bjGaAfv+HLcFwOu1lirbZvBiD5K9fDk5MfWtICaAse9TWBb09TbpqJQcX0rledPVuOmjiHwN3benwbdY6htnaWK1tSjLKM3q9AMx3mPIXSfKIc94HfjvG5XagLNufs+Uej0ZLB1lmDQ5rHXF9gdFWydJTbd7rNfG5hDBVtniQVtXnvuYQ8x2PYYUNDmt28i9iY6Nuy3C1vc57f3JRQ3BdseI+iXh9yDNtj2GEjQ5r0HLbSPcEvDvrOAiMN/H2Foz4ZQ22MAhMBe0EhHi2wIpl21/JkAVQZkP2+o7lwkROkJP9X+cEpV5Ap8L7QnO7qvvsqLVObgf5D2VGXLTjUBg8B99TlnI6jU3SXEvmp3zAVK18PPRmBNYmhF7mb9OydVnK+Cz7fgnP9wgVSprqVOcf0Glf0bSuB+YpxRwhinJaV6LbfGhH643sIvXlWcc2ZCHdglY1qUKXyC4A3N24ezzgrizJiS+ygKa/uLHznsR5BPMIt53lPQkwHPfmSA+wSjuGd2weeu2WSZe4LFP3ftD5yd9wfOP/z/n2H5B84h/QNnyf6B84D/wJnOf+Bc7qdDDH+2+pMhugN6ED4TogegD2E/fxaLKnx21/Yh7GfP4RcTNzeBED6H63dz9CDhMwRwTqEaTtifBsvNMUnpW4n1Jewv00ea1Dj1njXwJlRZ/+NGqgAWqgKE6mV8zEiVvq8gTNjfPWSkxqn7NAGX8CGe0c8Lsgn7m9l9H2M8Qze2RwmLx3i/t1GiD5BF2J+mYcry7Xxx6j8dGYKw6LW9R6UxMvXF3omwv5x0PlRlMuG1BvAI+/3hqlPnKMWKe+IZl1BZ1XlnjFLM+UeD8An7/UM3jIoP7+ooFYJQPccvywZ7uKLkK8zRLmEIVSCX8Y8sLiWFyKAQzaBQhErrNMzUp4xEyvIPugISqhggk9zGCqk+IWP497qCEip9TCLzChknqb+d1JbXMRWaUOmQzYBGhKKVYZaFMJ5EHRAq7dYLr2aSoh1lsQ5lW3R1Q1houM5SIeIW4yOjWIg0W3dzVmuh7gjPmn7uF2mUiDhWqFVF6opIonSx/wxqV+rqmPCi5fTj+L3P8u1qXmi1zbP99/Fj2s0xwkR3IXyo3oSvrzfh6+tN+Pp6E76+3oSvr/8AbT7RdQXNFCEAAAAASUVORK5CYII=" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-info" role="progressbar" style="width: 82%" aria-valuenow="82" aria-valuemin="0" aria-valuemax="100">82%</div>
              </div>
            </div>
            
            <div class="item">
              <div class="icon_font">
                JavaScript
              </div>
              <div class="icon"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAkFBMVEX33x4AAAD+5R+GeRByZw774x9ZUAv64R7/6B/u1x303B7izBtqYA3y2x0/OQitnBWQghFTSwq4phY4MwfUvxpEPQjm0ByyoRbZxBoqJgVKQwnOuhnBrhh7bw8nIwVPRwpjWQyaixOklBQWFAMeGwSKfRF1ag4LCgFkWgzFsRgiHwQvKwYUEgM8NgemlRSbjROjfARsAAAHC0lEQVR4nO2cW3uiOhRAybYxIFIQEa147c3xVO3//3cH67RHZQcShCaeb6+XeagwWeSe7MRxCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCDmcA7guOD2H5/8A56YThJAnsIhSQgV3g2QW9QfT0X64H00H/SjOPBcss4T1oFtg8FydSu5ODoNXds3LKMoAxC+kXBV4KCQypwNVj4lwiD14soxS1x7HWoYQRFK9E33fmnysYcid5wq/r1d4ltRHfUNIHhUEGXud2aGobQgqGXjiTdhQUjUNhZgrCzK2CixQ1DMUTl9DkLFRz7yiniHXE8wVHeOKWobQ0RRkrHtXhhBqCzI2rxo8tI2GIfdrCDIWGlbUMezWMmS+2X5R3ZDP6gmarorqhvBU09BwOVU2rJ2FOanJXFQ2dEe1BeeBAbEfVA1FSUO6WHXe3rv/SP46TFwTYj+oGkoH3C+f/nGFBlw3DbFJRyQMTzFUDd0pLvgQ/Ex1BfDxy9WflxOzGeioGwYbVPDtcioP6WU2Pluw+KZoyDNU8M+1AA/O8nrlmx6xHVE1jFHD4nCFe9/d5i62IAMdZUNAl5762NAnOf3twbMhAx11Q/RnYyyTvlrd3daa9URFQxcddU/wYjhiHdNdxBmqhgPUEM0nkWTGu4gzbstDvCRalIGOuuEK+1lmS10rQ7WlQZegIkuay1JUDdFl0qWRJGui2uMfsJ+x7R1koqohPv9dePbXRFXDBDVk055V7SaG8hx/hysOrRhdl6E8P5QuYoSO3dmoPMf/lBmyZWbNfi+G8jrNRGrIWDdTi94wgvpam2yl6YvpzLW1PiobAt4j/rA49OwsrBr7FuWGx6d8O2b1l2is6q8rFdlq61hXWDXyMJB0iReMQs+ywqqzuzZWMGTsaZ1a5aizB6y6i/8SpRaVVR1D4SlvsEWBNY5akQq8rNu/4mBLFKZetAls1RUXWzuqo2ZMFOjsk9qxKKwb16aTi2wXW6CoH7k30dnP75ifWulHX3JPJ/RrmppWrBFBK7hObNRTcj8RQ2cP+egiP87GsGK9SHbhzvA9YRTJBs4vUTNW3+Firez4ch/xNMUnvah43AJneJ+GjgBv/aGm2DG43XaD4fHpYKwWKpWZq4q3GebPO5lK9zi8X8Nj9+i/VSuai0+83fBYIZ2wdK2RmWxsmjB0jifZthWDAGMnaBoyPDompRVyZaqYNmb4dSKxxNFYt9+gYe4ImbzziA0V00YNjyf31jJDUwcvGjYsWQQYNJhqrQQ1beiAZEN8Y6giNm/ogGRt3P/fGDqAH64xNDZtw1ASmhLeiSEPvMqX9tBdqs92G1NZHcAD1t5kieGwHT5UptTdYy9tNQpOOImkiOBBh7LEuJM/+V9nVUnFYzWln60B3GS4kZQtjg6Yn/ETlsFpmlQZ64V/tvYMIXhn0oUED12HwEZY3B1/V6/CIYQr8PCitkrpz/ptgn14yXGmbeG3ApK9emLRlgYvGLeSJ+z7iAcaDCo5R1HouiB9v/jBofRaCby3aGXoDd5Z5OsaC7BAm9LN1fCDB4WYr7Bk9QzwybAkKvwWhBhfrGhmqmfuni5+yPkMuallLd3/lMUWNT8uheTqW24Kh3jwLGTd8wxyJ/ggrC/Z/5RNLh6bPmcJQfF6gN3kMlGu5FDh+eiDS28ZWMTIVj13ZRtT1QMFLYQbo0vu4VkQIXdl9+icN6WA9m0njvF6F5JcluFMcoSovqC/lPw/+9iBE8FYupl7nhaRyg2PoTPZ18uOd34B9OKSBbdmJ0/44YG/TDtRFD2U7Dj0L9pJaU5/M5qvPw+H5+i9dBOj23BvGFSkqpSrpU2huP1STtO9oUogoZSrry05P6rHR69ZwZxF7cQURgY3fa6/lA6CasF14l4uKc5CxJ9bBdvYtihtbMpABnciULveS04razQ9+aV4ZSywCsPT64P2esxb2QMWvka4xH9s0a/NU5UAYRmPLc0MtULQvpHegZVW7RDK+ae181+AT/7K6EpfJjzJvRGVvLYYT+PqKo5Kvrbo1Wu7PloNGAK9zvqx9DZHUeuur2XLoXvga7Tz3arDhOBrX4bVfvgld5RvkYuqo5Y5j7Xa1F1xWaEFIFHqGD/UQgg5X6sLRr90SohDXBnW+3pQTgyIg9JkYxf9Yph3XrhKY0H2YU8nMQDZe1XvOA1/+cQFh8nnEh/jjDoZ102McL3tXBqU8NR9nhg4cimA+9tOf3+muRmuOvHEqXf0Q4Dwt9HD8vVKbn5IPGPXXQsOEKT+JJvF8Syb+GmeFH5DWoQA1/FSP5nF43Acb5P8jcL8vewihx8RDd3y+/d1+Qu5FfcGEwRBEARBEARBEHfHv2qXXAHWGtN5AAAAAElFTkSuQmCC" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-warning" role="progressbar" style="width: 65%" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100">65%</div>
              </div>
            </div>
            
            <div class="item">
              <div class="icon_font">
                Bootstrap
              </div>
              <div class="icon"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw4PDQ8NDQ4PDQ4OEA8PDg4PEBAODg0QFxUWHhgVFRMkHTQiGBsoJxcVITEhJzUrLi4uFx8zODUsNyotLi0BCgoKDg0OGxAQGS8lHiUtLSsrKy0tKy03LSstKysrMS4wKy0tLSstKy0tLS0rKy0tKy0rLy0rKy0rLSsrLS0rLf/AABEIAMgA/AMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAAAQcECAIFBgP/xABKEAACAgEBAggJCAYJBAMAAAAAAQIDBBEFIQYHEjFBYYGRIlFSVHF0sbPRExQWIzI0YqEXNUJyk8EzRIKDkpSiw9JTc7LhFSVD/8QAGwEAAgMBAQEAAAAAAAAAAAAAAAEEBQYDAgf/xAA4EQACAQMABQkGBQUBAAAAAAAAAQIDBBEFITFRcRIyQWGBkaGx0QYUFVLB8BMiM1PhNEKSsvEj/9oADAMBAAIRAxEAPwC8QAAAA63b204YmLdkz3quLcY+XN7ox7W0j1GLlJRist6lxY0m3hHXcKeFmPgV+F9ZfNa10RfhaeVLyY9fT0alU7Y4Z7QyZPlXzqg+aqlypgl4m1vl2tnUbRzbMi6y+6XLnbLlSl/JeJLmS8SMY29joqjbRTaTn0t6+7dx2+RcUbWFNa1l/ewmc23rJuT8bbb7ziAWhJBIIGIAECAAAYgQCAECQQAAAkBA4gAIAEAIGXhbVyaNHRkXUtb/AKuycF2rXRmIQJpPUxNJ7SyeCvGZYpRp2lpOEtyyIR0nD9+K3SXWtH1MtGm6M4xnCSnCaUoyi1KMovmafSjWYsjim4RyU3s26WsJcqeO3+xJb3BdTWsl1p+Mzel9EU1B16Kw1ra6Gt63NbdWrG7GuFcW6w5xRa4AMsQQAAAAAABXXHDltUYuOuayydsv7uKST/ia9hYpV/HMvCwn1X+2stNDRTvYZ633RZItFmtHt8mVsQAbkugAAEACAAEggewQIBACBIIAAAAECAAEwAAAEAgBAkABAytk5rx8mm+OutNtc93SoyTa7Vqu0xAufuDkqX5XservDGdRtAD50rSEV+Few+h8xKQAAAAAAAVhxzPfhf3/ALayzyq+OSf1uJHpULH3yj8C20J/Ww4S/wBWSbP9ZdvkyuQCTblwCAAAgkgDEATVCU5RhBOUpyUYxXPKTeiSO6+hu1fMru5fE5SrU4c+SXFpeZ5lKMdrOiJO8+hu1fMru5fEfQ7avmV3cviefeqH7kf8o+p5/EhvXejogd59Ddq+ZXdy+I+hu1fMru5fEPeqH7kf8l6i/EhvXejoyTupcD9qL+o39kU/5nXZuysula3419K8qdVkY97Wh7jWpyeIyT4NP6jU4vY/FGICPyJOgwQCAEACQAAEAIBc/cB0nqHOXEFtNnavsx9C9hzMbAnyqapLmlXB98UZJ8v2MpAAAAAAABT3G9bytoVw8jHrXa5zfwLhKH4wMr5XauTJPVQmql1chRi13qReaAhm5ct0X5pEuyjmpncv4PPEAGxLYEAkaEQCAwAzuD337E9Yo95E2ONceD/3/E9Yo95E2NMp7Rc+nwfmVl7zlwJIJK/z+M/Hpvtoli3SdNtlTkpV6ScJNNrf1FHQtatdtU45wRIwlLmosAjUrr9LOL5rf/iq+JH6WcXzTI/xVfEk/Crz9vyOnu9T5SxNSGzwmPxp7PlorKsqpeU4QlFd0tfyPV7J2zi5cPlMa6FyX2uS9JQ6pRe+Paca1pXo66kGlv6O88SpyjzkdTt7gTgZicnUse181tCVctfxR+zLtWvWipOE/BrJ2fao3JTrnr8ndDXkTS6Pwy6vaX+YO2dmVZmPZjXrWFi01/ahLolHxNc5NsNK1beSjNuUN27h6bH4nWjXlB42o1z1BlbVwbMbItxrftUzlBvol4pLqa0faYxtoyUllbGWeekAEDAAAABHSvSCBiybF8FreXs3Dl48ajX0qCT9h255HivyvlNk0x11dM7an1aSbS7pRPXHzm8hyLipHdJ+ZTzjyZNdYABGPIAAAY+bkxqqsunuhVCVkn1RTb9hrjl3yssstn9qyyU5fvSbb9pb3Gltj5HCWNB6WZT0enOqlvk+3wY9rKdNd7P0HCjKq/7nq4L1ee4s7GGIuW8EAkvyaCABgCCCQAzeD/3/ABPWKPeRNjma48H/AL/iesUe8ibGNmV9oufT4PzKy95y4E6mufCdf/ZZvrWT72RsWa68Jv1jm+tZPvZB7PL89TgvqebPnvgdboRocganBZHFoytk7Tuw74ZFE3CcH/ZnHpUl0xZjnGR5nBSWGso8tLGs2O2VnwyManIhujdXGxJ88dVvT9G9dhlanmOLZSWx8Xla/wD6uOvkuyen5HptT57cU1TrTgtibXc2VEo8mTRUHG/iKGfVctF8vRHldcoSa17nFdh4hHvuOS+Ly8WtfajQ5S6lKb0/8WeARttFt+6U87vq8eGCyofpoAAnnUAHEBAAAIs/iX2j96w2/JyK13Rn/tlpmu3BDbHzPPpvb8BS5FvXVLdLu5/TFGw8JJpNNNNapremjGaet3C4/E6JLxWp/R9pXXMMTzvOQAKQjgwtqbRpxaZ35E1CuC3t87fQkulvoR4/aXGfhwTWPVddPo5SVVfa29fyK54Q8IsrOsUr5+DFvkUw8GuHoXS+t7y6tNCV6ss1VyY9e3sXr/BKpWk5P8ywvvoOHCXbVmdl2ZFm5Pwa4f8ATrX2Y/zfW2dWCDYwhGEVGKwlqRbJJLCAAPYAgEAIEghgBncH/v8AiesUe8ibFs104P8A3/E9Yo95E2KbMt7Q8+nwfmVt5zlwGprtwm/WOb61k+9kbEFf7Q4s6777r5ZdkXdbZa4qqLUXOTemuvWRtD3dK2lN1XjKWNTfkc7acYSbluKmBaX6KKfPbf4UPiFxU0dOZb/Ch8S/+M2fz+EvQme9Ut5VrZ2OwNiX518aKIbt3Lnp4FUOmUn7F0ln4PFns+D1slff+GU1CHdFJ/meswMGnHrVWPVCmtfswiorXxvxvrZCudPUlHFFNve1hLr3vh/w5Tu1siTs/Ehj0VY9S0rphGuGvPpFab+s+mTfCuErbJKFdcXOc5PRRilvbMbam1sbFg7Mm6FMejlPwpdUY88n1IqPhvw3nnv5vQpVYkXq091l7T3OfiiudR7X0aUdnY1bufV0y+9r4EWnSc31HR8JtrvNzbslpqMpaQi+eFcVpFenRavrbOuOKORuacFCKjHYtS7C0SSWEACD2AIAAQAACBbfFdwsjbVHZ+RPS6paY8pP+lrWnga9Mo/mvQypCYyaalFuMk04tNpxa5mn0MiXtnC6pOnLinuf3t6u851KamsM2hBUHB7jRuqiqs6p5EVuV0Hpbp+JPdJ9e49VDjN2U1q7LoPyZVvVdz0MdW0Rd05Y5Dl1x1/z3pECVCa6CmgW5tHivxJpvHtupn0KbVtfduf5lc8IuDmTg2KF8PBlryLob65+h9D6nvNba6Rt7l4py17nqf8APYy1p3FOpqT17jqCQQT9h2BAIAQJBAACCSAEZ3B/79iesY/vImxMjXbg/wDfsT1ij3kTYhsy3tDz4cH5ldec5cBqQCieEG3s6GdlQrzsmEI5ORGMY5N0YxirJJJLlbkvEVljYyu5NKWMHCnTc3hF7EGvf0j2j5/mf5m//kR9I9o+f5n+av8A+RZfAJ/Ou47e6z3rx9DYUamvtPCnacHrHOyv7ds5rulqd/snjNzqmlkwryYdLcfkrOySXJ/I41NB3EVmLT6tj8dXiJ201s1lj7V4KbOytXdjV8qW9zr+qm343KOmvbqeA4ScW1tMXbgzlkVx3ypkk74r8Om6fo3PxJljbC23j51Cvx5NrmnCWisql5Ml0exnY6kahfXVrPk5erU4yy/PZ2NHONScHjPYa2Nabnu8a6USWXxocGIuD2jjx0lFr51GK3TTeit9K3a9W/oKz1NhZ3ULmkqke1bnu+9qLCnUU1lEnEAknoAABAAAAIBMINtJJttpJJatt8yS6WAiCCwuDnFffdFW51jxYveqopO5r8T5oeje/Qesr4sNlpaON835Urmm+5aFVW0zZ0pclyy+pZ8dnccZXEEe2MLamzacqiVF8FOua3rdqn0Si+hroZmgw6bTynhorthrxwl2LZhZdmPPfp4Vc+ZWVv7Mv5PrTOrLh41dj/LYSyoL6zFesn0upvSS7Ho+xlOm/wBG3fvVuqj52x8V6rD78F1Qq/iQz09JBJBJOOpAAAQIORxYAZ3B/wC/YnrFHvImw7NeOD/37E9Yx/eRNhmzLe0HPhwfmV13zlwBr3wm/WOb61ke9kbCamvXCf8AWOb61ke9kHs/z58F9RWnPfA64kgk1RYEaENHIgQj0fFztOWNtKmHK0ryH83mtdz5enIfpUtO9+Mu4oLglXKW08JRWr+c0S7FNN/lFl96mU07CKrRa2teTePTgkQLlJTXA4ZNEba51WJShZGUJp8zjJaP2mu2Zjuq62mX2qpzg/SpNP2Gxhr9wla/+QzNOb5zk+8kdfZ+TUqkejU/NDtnraOvABpiYAAAgAQAgW3xXcEo1VR2hkw1tsXKx4SX9FW9NJ6eU+jxL0lecD9kfPc+nHabg5cq7qrjvl3839pGxEIJJRSSSSSS5kl0Ge09eunBUIPXLW+G7t6epY6SLc1MLko5gAyRCAAADHzcaNtVlM1rC2Eq5Lxxkmn7TW/Lx5VW2VT+1VOcJfvRbT9hswULxhYvyW1sqKWinNWrr5cYtvvcjR+ztXE6lPek+54+vgTrGWG12nnSCSDVliCSCAEAAAjN4P8A37E9Yo95E2GZrzwf+/YnrGP7yJsKzL+0HPp8H5lfd85cAa+8Jv1jm+tZHvZGwGp4jP4uMa662+WRkRd1llrilXpFzk20t3NvI2ibulbSk6j2o50JxhJt7ipNSNS1/wBF+J5zkd1XwOP6L8TzjI7qvgXvxm0+Z9zJfvNPr7iqtSNdebeW3DixwE9ZW5U+rlVRT/0and7K4J7PxWpU48XYt6st+tmn403zdmhyqadtor8qcn3eL9GeXdQ6EzyvFrwVsrl8/wAqDg+S441clpNcpaOxro3apLxN9RYoBmbq5ncVXUn/AMRDnNyeWfDOy4UU232PSFMJWS9EVqa7W2SnOU5falOU5fvN6v2lhcZ3CiM09nY0uVpJPJnF6x5Se6pPp0e99aS8ZXaNJoS2dKk5y2yxjh0d+3hglW8HFZfSSAC7JAAIAQAAAWfxLbOWuVmNeTj1v/VP/bLUPIcVmL8nsimWmjunba+vWTin3RR68wOlav4l5Ue58nu1FZWeZsAArzmAAAApzjfrUdo1TX7ePW+1TsXwLjKp45ofXYkul12LulH4lxoKWLxLepeWfoSbR/8Aqu3yK4BINsWpxAACABACM7g/9+xPWMf3kTYNmt0LJRlGcG4yhJSjJc8ZJ6po7l8Mdq+e296+BT6T0fUupRcGljO3O/qTI1ejKbTRe5BRP0x2r57b3r4EfTHavntvevgVnwKv88fH0OHus96L21IKK+mO1fPbu9fAfTHavnt3evgHwKv88fH0F7tPqL1BREuF+1H/AF67skl/Iw8jbWbatLczJmn0Svscf8Oug46Bq9M13P8Agfu0t5eW1dvYmIm8m+utr9jXlWv0Vrwn3FdcKOMay6MqcCMsep6qV8t181+HT+j9O9+g8Go6EpFjbaGo0nypfmfXs7vVtdR1hbxWt6yEtOc5AFydwAAECAAAEdK9JBJ6jtQGxvBSrkbNwo82mLRr6XBN+07cx8CHJpqiuaNcF3RRkHzKpPlzlLe2VAAB4AAAABVvHUt+E/8Av+2stIq3jpfhYS6r/bWWuhP62HCX+rJFr+qu3yZWpxANyWoAIAQIJIAASAMRAAABoRoSQIQIAAQAACAAAAQAAgcQAABfAD/0eo85cQ6TaKr7K9COZ86HrCL8cV7D6Hy8p0AAAwAAAFcccmI3j4uQuaqyyuXUrI6pv+Hp2ljnW7f2ZDMxbsae5WxaUvImt8ZdjSZLsbhW9xCq9ievg9T8GdKU+RNSNcwZO0sG3GusoujyLK5cmUejqa8afOn4mYx9CTTWVsLjIIBAwBJBIACCSAEAAAgcQAEAAAAAAIEEkAIAHEAAAAQMrZWHLIyaaI663W11rTfprJJvs3vsMUsvij4NSdj2ndHSEeVDGT/bk9zmupLWK62/ERry5VtRlVfRs49H3uy+g8VJ8mOS2UtNyJAPnRWAAAAAAAAAAHm+FfBLH2hX4X1d8VpXfFLlaeTPyo9XR0aFS7Z4F7RxW+VRO6C5rKE7oNeNpLlR7UiQXGi9J16U40dsX0POrp1a16HelXnDUth5+cWnpJOL8TTT7jgAbWLyslqSABiIAACBAAAQAAEAAAgAAEQAAA4gABEmVg7Kyb9FRRdc3u+rrnNdr00XaAcq9R04OSPFSXJWUWBwV4sbHKN209IQjvWNCWsp/vyW6K6lq+tFqUUxhCNdcYwhBKMYxSjGMVzJLoRIPn93fVruSlUfBLYs/e15ZXznKb1n1ABGPAAAAf/Z" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-info" role="progressbar" style="width: 83%" aria-valuenow="83" aria-valuemin="0" aria-valuemax="100">83%</div>
              </div>
            </div>

            <div class="item">
              <div class="icon_font">
                Python
              </div>
              <div class="icon"><img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPDw0NDg4UDQ8NEw4ODw8NDw8QDQ8QFhcXGRYSFhcZICkhGRsnHxYYJD8iKC4sLzAvGCA1OjUtOSkuLywBCgoKDg0OGxAQGzknICYuLiwsMS4uLi4uLi4uLC4sLi4wLiwuLCwuLC4uLi4uLi4uLCwuLC4uLiwsLi4sLi4uLv/AABEIAOsA1gMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIEBQYHAwj/xABKEAACAQMAAwoICA0EAwAAAAAAAQIDBBEFITEGEhMyQVFSYXGRBxSBk6Gx0dIVFiIzU1RysxcjJDRCYnN0gpKisvA1lMHhQ2Px/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAECAwQFBgf/xAA1EQACAQICBggFBAMBAAAAAAAAAQIDEQQhEjFRYZGhBRQyQXGBscETFSLh8COi0fEzQlIk/9oADAMBAAIRAxEAPwDuIAAAAAAAAB43FeFOMp1JKEI65Sm0orysrnNRTlJ4UU229iS2s5Nuj05O8qt5aowb4KnyJdNrpP0ZwZqNF1XuMNasqS3m2aR3d0YPe0Kcq76UnwdPyZWX3I1+73bXs+JKFFcnB0033zya22elS2qRjv5Upxh0pQkod7WDoRw9OPdx/LHPliKku/h+XLuvp+8nxrur/BUlBd0cFnUvKsuNWqS+1Um/WzwbIbM2ilqXJGJyk9b5smUm9rz2kKo1sk12NopbKWwQXMNI148WvVj9mpUj6mXdDdPfU+Ld1P42qn96ZiGyGyrhF60WU5beZt9h4QrqDSrQp148urgqnetXoN10Dunt7z5NOThVxl0avyanW48kl2eXBxliM3FqUW4yi1KMotqUWtjTWxmGphoS1ZMzwxM468/zafQYNP3DbqXdxdvXa8Zprjalw0F+ljkkuVdeVypbgc2cHB6LOjCamroAAqWAAAAAAAAAAAAAAAAAAMFuzrunYXDW2ajT8k5JS9DZyhnTvCE/yF/tKXrOYNnSwa/T8zm4x/qeRv24HQlPg1e1Iqc5SkqO+WVCMXhyS6TaevmXWzdWs6nrT1NPYav4PtIRqWioZ/GW7mpR5XGUnKMuzW15DajSxDbqO5u4eyprR/Gcv3d6EhbVKdajHeUq++zBaowqLGzmTT2cmGaq2bv4TdIxlKhaxacqe+q1P1W1iMe3GX3c5ozZ0aDbprSOdXSVRpBspbDZQ2ZjCGylkspYJDIbDZS2QC40bfytq1G5hxqMlPHSX6UexrK8p3ulUU4xnF5jNKUXzprKZ88tndtzLzY2Le3xe3+7iaWMWUX5G9g3rRlAAaJugAAAAAAAAAAAAAAAAAGs+EL8xf7Sl6zlzZ1Pd5RnUsnGnTlVlwlN72nCU5Yy9eFrOdPQ119Ur+Yq+w6WEaVPzOdi4t1Ml3ItbW6qUZqpSnKnOOyUHh9nWuoy9XdlfyjvOH3vI5Rp01N+XGryYLB6FuvqdfzFX3Sl6Fu/qdfzFX3TPJQlm7GCPxFkr8yxnNtuUm5OTbbk25Nva23tZQ2X70Ld/U6/+3q+6Q9CXf1Ov/t6vultKO0r8OWzkY5shl/PQ10k27Sukk226FVJJbW3vdRjmwmnqDTWtBshslspbBAbKGw2UtgkNndty/5hYfu9t93E4O2d43L/AJhYfu9t93E08b2V4m5hNbMqADQN4AAAAAAAAAAGG3Q6fp2cE5fLqzzwdJPDfW3yR6yYxcnZESkoq7MtOainKTUUtbbeEl1sw1zursqbw7hTf/qjOou+Ka9JzfS2l691LfVqjks5jTjqpR7I/wDLy+sx7N6GCWub4GjPGv8A1XE6f8eLLpVPNSI+PNl0qnmpHL2ylsydTp7zH1upu4HUfj3Y9Kp5qQ+Pdj0qnmpHLGyGx1OnvHW6m46n8fLHpVPNSHx8selU81I5U2UNkdUp7x1upuOr/H2x6VTzUiPj/YdKp5qRyhspY6pT3k9bqbjqOkN3NjOjWpxlU306dSEc0pYy4tI5aGylsy06UafZMVSrKprDZQ2S2UtmQoQ2UtktlLYBDZ3ncu8aPsOq2tvu4nBTvG5n/T7L92t/u0aWNf0I3MH2mX/jsP8AEPHYf4jHA8gulK+7h9zs/AiZHxuHO+5ntCaexp9hiBGbTynh9ReHStRP64prdl6toh0F3MzQLa0r79a9Ult6y5O3TqRqRU46mazTTswAC5BaaRvI29KpXnxacXJ875orrbwvKcg0lfTuKs69V5lN56orkiupG6+Ei8ap0bZP5xyqz7I6op+Vt/wmgM6WDp2jpd79Dm4upeWjs9QylslspbNs1CGylslshsAhspbJbKWyCQ2UMMpYJDIYbIbADZQ2GylsgkNlLYbKWwA2UsMAA7xuZ/0+y/drf7tHBzvO5xYsLJPU1bW+er8WjSx3Y4+huYPtMoIyCMnz3uPQAjIyQQSV0au8kpLk9POZlPOtcpgcmWsKmaa6so6/RFe0pU335r35W4GviIZKRdAA7xqHLd3tzv76pHkowp0l3b9/3+g1xsvtO1t/dXU9uatXHYpNL0JGPbO1TVoJbji1Hebe8NlLYbIbLlA2UthspbIJDZQ2S2UsEhlLYYbAIbKWyWyhsgENkNhspbBIbKWw2QAAAlybc6kltb5iAXOjbKVzWo20ONXnGmscie2XYll+Q75XSp0t5HUklCK6sYx3Go+D3cnK2XjdzHe16i3tOm9tGm9rfNN+hauVo2W9rb6WFsj6es4XS+MUKbSe1LxevgdXA0Gs3+ItskZGSDxh2BkjIyUlSSS/0VPXOPY/aY4utHSxVS5016MmzgKmjiYeNuOXuVqq8GZkAHrzmnC6099KUuk5PveTzbK6sd7KUei2u5nm2dw4YbKWw2UtgBsobJbKGAGQyUm2kk220kkm229iS5WdH3LbhoQUa97FVKjw40Hh0qf2+ScurZ27THUqRpq7MlOnKo7I0XRuhbq6129vOpHp4Uaf88sJ95nYeDu+ksudGHVKrUz/AExZ0+dzCHyduNWFsXUeLv3yRXlZx63TFOErXXBs6NPAK2efI5w/Bve/S2/na3uEPwbXv0tv52t7h0jx6XR9Y8el0PWYfnlPb+1mTqC2czmv4Nb76W387W9wh+DS++lt/O1vcOl+PS6HrHj0uj6x88p7f2sdQWzmcz/BpffS2/nK3uEfg0vvpbfzlb3Dpnj0uj6x4/Lo+sj55T2/tZPUFs5nOrbwYXLf465pU1z0o1Kr7mom36A3HWlk1VSdatH/AM1fDcPsLZHt29ZlJX8uRY7y2q1pS4zb/wA5jXr9OxcbRu+S/nkZKeBUXe3uXN3eZzGGzllzllkZIPO18ROtLSn/AF4HQhBRVkMkAg1y4yQCMlblge1m/wAZT8npPDJ6WfzlP7S9Zei/1YeK9SJdlmwgA9wck4np2lvLq6hs3tWtjs3za9GCwbNi3f23B39V8laNOqu7ev0wZrjZ2abvBPccaorTa3kNlLZLZQy5QMpYZKi21GKzKTSiudvUkAb74NdAqWb+rHOHKFunsytUqvriuyXUbxd3H6EfKxZ20ba3p0YbKMIwXW0sZfa/WWR5PpfGSvoxev0+/wDJ38JRUY+HqAAedN4AEZAJIyQRki5NiSMkZIyVuTYkpyMkFGyQRkEFSwIBGSpIyRkZIyVuSMlxo5Zqw6s+hFrkyOhYZlOXR9b/APhsYGGniacd6fDP2KVnowbMwAD2xyjQvChZ/JtrlLiuVGX8Xyo+T5Mu8582dt05o5XVvWt3q4SPyZP9Ga1xl5GkcTr0pU5Tpzi4zg3CUXtUk8NHSwk7w0dhzcXC09LaebZDDKWbRrBsvNBrN1Zp8te3X9cSybLzQT/K7L9vb/3xKy7L8C0O0juF9xH2oxxkb/idxjjwnSf+fyXqz0lHsgAg5xmGSBkpyVuTYnJGSCMlbk2JIyQRkrcsCAQUbJSJIyRkjJUkZIyMkZKtlhkjJJBVskgzui6W9prO2fy35dnowYe1ocJOMOR631I2U7vQlC8pVnqX0r34avNmpi55KAAB6Q0AaXu33KO5zdWyXjCSU4akqqWxp9NbOtdiN0BeE3B3RWcFNWZ8/VYShKUJxcJReJRmnGUXzNPWmUNncdKaEtrpflFCNRpYU9caiXMpxw0vKYGt4O7KTypVoLmjUg1/VFs3o4uDX1ZGhLCTTyfscqbLvQL/ACuy/b2/98To/wCDez+luP56XuFdr4PrSlUp1oVa++pTp1YqU6W9coSUkniGzUTLFU2mvYRw1RNPLibRf8TuMbkyWkOI/IYzJ4vpT/P5L3O7Q7IIyMkHMM4yQRkgq2STkgmCy4rnMn8HQ55fzf8ARsYfB1cQm6fdvKTqRhrMUQZX4Nhzy717B8GQ55d69hn+UYnYuJXrFPbyMTkjJl/g2HPLvXsI+C6fPLvXsI+T4ndx+xPWaf4jEZKcmZ+C6f63evYR8FU+eXevYV+TYrdx+xPWaf4jDZIM18FU+eXevYPgmnzy717CPk2K3cfsT1qmYUmEW2kllvYltMytGU/1n2v/AKLmjbwhxIpf8l6XQdZy+uSS3Zv0t58issXC2R46OtODjr40tpegHpaNKNGChDUjRlJyd2AAZCoAAAAAAAABa6R4j7UYvJlNI/NvtRisnm+ln/6PJe5u4fsDJGRkpOWZySCAVuWCeNa2o9vGqnT9J4ZKciNWcey2vBteg0U9Z7+N1On6SPG6nT9J4ZEU28JZb2Ja2yesVv8At8WToR2Ht47U6b7yPHKn0j7yZWNVLPB9zTfdtLYmpUxNPtuS8XJeojGEtVuR7+OVPpH3mdtm3CDetuKbfO8GtmyWvzdP7MPUjrdCVJzqT0m3ktbb797NbFxSirLvPYAHojRAAAAAAAAAAAAAAAAAALTSXzb7UYkzdxDfwlHla1GDZ5vpiLVaMu5r0efqjdwzvFoZIBGTkXNoEZGSMlWyRkjJGSMlGybE5MvoiklBT5Z5182HjHoMMZbRFwt7wT2ptrrT1nS6IcFiVpbHbxy520jBik/h5GUMPpmgk41Fqzql1vkZmDCaWuVJqEXlRy21s7Dt9MOCwslPy8f6vfdc1cMn8RWLA2S1+bp/Zh6ka7SpucowW2T/AMZs0YpJJbFqRz+gYO8592S89fJGfGSySKgAejNAAAAAAAAAAAAAAAAAAAGOvrPOZwWv9KPOZEGHEYeFeGhPVzT2r83PItCbi7o1tlOTO3FpCpra185jqujJritTXceZxHRdek/pWkt2vhr4XN+GIhLXkWWSMldWjKPGjjrefWeZy53g7Sye/I2VnqJyQCClyQAetO1qS4sM9eMLvZMIOo7RV/BX5INqObKXXm1hzbXM3qKIRbaSWW9iW0yNHRMnx5KK5o6/TyGSoW0Ka+Ssc/K2deh0TiKzTqvRW/N8O7z1bzVniYRyjmW+j7Lg1vpa5vuRfgHpqNGFGChBZI0JzcndgAGUqAAAAAAAAAAAAAAAAAAAAAAAADynQi9sU+1JnqCGrqzBbOyp9BE+J0+gvWXAMaoUl/ouC/gtpy2nnTpRjsSXYkegBlWSsioAAAAAAAAAAAAAAAAAAAAAAAAAAABDKGAV5Kd+UMoYB68IOEPJlIB7cIOEPEAHvwg4Q8CUAXG/JyW6K0AewPNFaAJAAAAAAAAAAAB//9k=" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-success" role="progressbar" style="width: 97%" aria-valuenow="97" aria-valuemin="0" aria-valuemax="100">97%</div>
              </div>
            </div>
            
            <div class="item">
              <div class="icon_font">
                PHP
              </div>
              <div class="icon"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAAnFBMVEVHZsz////v7+8+X8pDY8v59/E8XclNa84/YMpIZ8xFZMz19PDz8vDu8fpObM5BYcrh5vdqg9ZadtH5+v2TpeHP1/JTcM9viNfs7/pjfdTI0fD09vywvel6kNpdeNLc4vW+ye2brOOBltyKnt+ZquPN0+jDy+aquOfAy+60weqvu+Lo6e7h5OyKndq5w+TR1+nb3uuntOCgrt81V8gRlXqMAAAPEUlEQVR4nNWdZ5uqOhSFUZRiAUWKqOiIzljOOMX7///bDU2zQwogKLM+nec4al6Tlb1TSKROI5qNN4vVdhdMfctQJUlX3fXUC+3DmzNZNvONUu2fOHdO29Bbu6j8eamGNQ3sw6J+nFpBls5qN3VpADmgdbhdzOv87tpAZptDuC7CcJfrbRfjur6/HpDlwvb1chQZTLia1FKEGkCWx51VCSKV4R1qYHkYxLFLNigqS/D2aBt7DGS+8h6nSGTZm5eBbOyHmhQpPTjOXgHihNRI8ZCmq8rxpSrIIqidIpZfFaUaiNMQBtJgfaiEUgVkE1aLGUXlnyp4pTzI3K7fG6Q8p3GQ2arWnoolfVc2ESsJsqktbohkrRoEWW6bb1V3BaUiZBkQZ/pEDCTj0AjI7PDM6kgUFM8mC4NMmgsdHFnHukEWT+msKNoXjCkFQa7NhkCevGLNqxDIOHwZBtK6UHQsAjJ5cm9FSj3VA+K8yh53besAORqvxkDaCTNiIcjq+dGDpkBEIgI5vJogkyeYnRCAbF9d/rs8fj7MB2kRBxrQc0m4IK3iQCS81sUDaY0/MvF8wgFZvbrceXH6LjbIWzv6XagdM4VkgjhtiIN52WVBJq/PS+hijRoZIMsX54ls6YtSIC/N2/ly6XMSdJDrq0vL05TadVFBFq8bDxbRrijIvK1Gz0Sbu6OAzF4yX1JGBsUmFJDWZSZ5UWySB9m0MaKT2otB2htBcOm5mZUcSMtSd5Z8snGRIH+iYUUiGxcBMnva+sejUjdckNOry1dcHg+k9aEQ14kDYr+6cGVkjZkgf8bpibZMkBYn7zQZEwaI0+6kN68dA6T1ySIpvAvGQJxXl6u8dlSQP1choEruIA04xIzUQxoMBrV/eKwdBaSBLsuPZCG5htFMR3LvuG4g9ceQnvXZ7Xb/fSL9/Ly7zdTJNgdSf1CXg+Fo1B3F6r/3av/8WLfwnoGMC+0ELyXF7ncz9X/l2j8/0YkAaWDqXT5jILumQDwIMmtigPs9vIF0p02BZINeqbG+t2f9G2UYo8+GvC7d5uelpqwuad69QoYfjXFkdk9Alg0MqJ7jdaQ3DGTRwOcDr18aBAkxkF0Dn6+/35vWaKo18A2p3PkNpImWZUKvNxQPY51uII20LO/G0R2+N+d1KW1bUkN9lqRcnuT1tN+KQGa++I9L/6TQ60qVAhbWIgXZiKOhHufGAw1JVjLJkTRW68e83vUarZF4+jQCES6IDNSPn/cPpC+k8y/SdXu9bi+XSxj4bk+W8/WFcnjM6zqCztg1s3bDTFMQ4ZBK87vDWH2g+L+6P++/gaqQ9aJhXh99Hq7X695GCsNgahmmQkGXemg4qcHqTv4hRFcnMYi485VDrJmQGg37w5+tS7gAj+vdbgfXcrK4BoZikuj2AukNaXVA2u73ezvc7XaB5/mGSav1u95iEPHsiXztMzmS/rX/eemBkuFeJ0BizVe+DFFM9q7Y5dw5BIbMDqp2DCIeimgfApAI5UsFX4R7fUQr3Wzl4l3AQBVsVJ4f/FwDzuTFIML8ZGD8cJpWpv67e/+Jca8zQKL9xFh71Hzh3vHlQWX0fihLQSDCMZXpizEiko97tMHjerfLKuLSv1eiHIo4kDas8ZmDQObC0TrX6zjJ9vYLyxe+RbKC3SOYfC0A0hkzSFYIROx1ZSu0SNKCurckV+T1TOGtXBpj1w9J4lMtbyMQ8Wqb+YXVyPAWUYbDEUHS/7qVC/c6B+SYFUvo9UwbndYPewhEvB6t4l6/hpcwvFz21/PHD+qrQKMbdf3E7z0X8/qozy7W3EiLZYq9nmpLy9vWS0kc100fjCyiUBvFXE0y/PD3B1RL5hLNw+h+rofDCsU5x3E25DbRWUpezOuxxrSxjTqRxAvScoDNIuAji4EpK/qli5EMP5JygRz+/J+cytRd7w0Wa5qCKLjXHRuF9f32cFpsxvmKolaJI42Fz9UrV7xURK8xUC545EuHgvIv9hYbe0tPVuBKf5CaxMS9bv+X5lum5E7DFbGivqEV8iRthLtJtS/uyMIEvk76rQH2f0OYww80kIqkNTLQca9j7+hFtU48/EabALhKR9EsPIzr+ZEFSA9H8S+Me330acE2DRpRJ/UI8PqSeMdA8YG3aNOvtrQSjarMdZc7iyAHuEl2UY3JU3y8ToLjS5hZmZWA23aULQ5yoJgklIS9L/R6/nVtirWsYdz05AvHVQq+B3miDvIlPeV+cdg5HylNy5OEKSMe1/vn/I+BQEYEiAK8TrwF5CJOWiYZf3Byn/sSGC4dSv/rS8IlUOB1O988ZSxmoKYV/cHgA5ub84jfD5Q5bSWwoOQ7IuE9hEOJ7WtJmPvq33ipKCAB3v9GZgde/0c6V8d70zTXMtccr8d/IAKxJNFUkLn+x+6BIikg0Y26Rtw1w3ed/DyszLM0BdTwuE6LE2DrH61puZJowK4JvA6CX/L7g7j+RdShjPdPWaoFvP6Wr3XY9GhmNyRRPIRep3yEiRli+B31Qsy4nivzIk1QNOD1PEjPxbcwrihxRJVE8RB6Pd9pgUS3/xWRmuy4TpQ5iwggrgf5cmpT7HVqsiWcYxxAr+drBJ/A6vajnpPrdVjmXeZ17AdfWuREERFEsdFYCYGVwFypJJhSJqTA6985r+ONJM20gG8mlB9XxnfDz+iDREGd4AkIzeugxoY/kXnl3f1/cnG9gNdpxcS77CwbIDAEHlH2nB5IIqZLkmLz4zqexd/iOj5IoTgAZiiUXi0CEcyhyIK4jvcFabwEcZ10LijzIXkR5vBBvkZAekZNflF9CMZVwOv5/gRUSGIIlPZjrlqTrtrkiySM6+BNy3W+M4jiCD9FAXE973UTX/FMR114EonQYHs2LbyRpF4X5PDwdWo4jFIU/pAdxHWyB5JkCW9YyOoRqLwrHddx3xwpFgFjSnrna0n8SRQY18FH9DTFwjmyYTCI62RGDsqc5UzQ65QhKM7BWF7zJf5CKPT6f9G2vp4ZzQbJPSv4/QQcaees4SkL6SoNL/Mqo8QtEJA1onhgImVHX46cSvx1N+D1ixsrPl71/P457ONTWqN0AxA+xEdeJ41J8XoPj5Ez+A5T0eBxD/SJRgkNq954ERGP60j/EkWrIX1yvjSbX9GwqfticV2DXtcGSHG9K7K03hFTwpRELNZO4j5cDFcH0m19I3LKN+b4zYIbNnWf5JDg87AyzV2K1xeGa6iq4Vrrabg/bcjndvLD+VRbift0sWwXm4dHRc7WRsB0HhmlZaHXZ+PxBGlMmWGM6stgrVmtJO7DYfJXMZD+l559Qw9bpst5Xcaf+ciGFXrhA8HGPjPvXUjcDdi419ka9c9SxkHEdcLroMxp/2NaRY8zXHrMDRT6RuJtRCG8zqqO7ta81TiM6yr5eaIcviKH5I4l3qIu4XWqhv1v/AuUEI/rhNc13OvZ8oDMPDQAaszhkKYdibfHSRF4Pdor8H3R8eJCr/MmGbNJHaXIWU3I52x/SNFOJwmNU5gva/hK4BDs3Ij+Mfr3fQ5UBUQorbDXT7S4ztSKtTKd6IpAlpxEHt/N93E+n7+inTXvSB8f5+slWOuyBgPtwP2871XpForrRbx+9JibkBIdo3V2ZrcFdvj8s+KtPSjPil4yox0vcn5gMDAuF/uK9IuwyfPeetZkOUNKCpdOZGgen6Gz3BympmC6QZ1EIMz5eLCbL5fDs96U7e5JkXHp7jp6EMOLFKQtGvhmfnQibSaxNs5xZQeWRPnBCKGhsMTZ0QhWB8geqJJ68aMx8fa1jBL4ZvufGT0zoybSe/HCY4HPDeO9KHNWtqWcOdlGbQI5fDqIT1X4M1bJxjPmIPGdM7KoScDrt8XqkoqmuCMQhkngjCF1yP+4gNepM1YFFA0OIhCGSaDXK36HSCCuLyr+WNGiRATCeJqHuzpQl4DXrxW/5JSCMHZxgJ2712d4vdLsdLI3MwGh542DZ3jdBV6v1sXHNotBJrQOGHq9Yn8iEvS6Uc2H1xsItQPGFz6GPw096Q7i+qJahSSjtQSE1rbwuD78aqZCoNdpOxoKKFnNkjqstqU8w+u9Grx+wEAoGfBA+r6PP/oVv0OknovtlqkY19MF3xTkLff6wPj9Op8/4gHI93tudaAeAa/Pq3k9HfKnIGPK7JYmx1mqrOl6U2cowLFvNR+eAMiLDhLR7MVt/DGvll9nSWcGUuBhmCZkyj2UtOvR6IN+g5dQWZ3eHgMPG32eS6B43rpSAXpzEmTR5AN2zek2u3cDKfLEWAu1yIG08TBZse6rWXcQ3vxWa3XfoYOdi/IHTgMkNZ3RQP5glWBLRPjZQX/OJfh6Lw6y/GsdF75QCs7Xent1ycoJrBABkL9zJmAk1WGC/K2jwuBpucTxhk2cmdCQrDkP5A+db0gc+kseAfpnumBvxgdp/6nFicgTQPOny4ofVWqFcs+R5g8u/hMpF9mwqEdJ/4HGRTkUmwLS2tsI7qIcU047bv3Y9rBIe4qUegD+/tUl5WtNu+OGCtLunMugHg5Bv1uh1Tah38HJuO2ipdeoRGLsimJdpNLaw7EDxnPvzKttWnp+PPMKKPZlQ63M6C3mgQpskGULI7zLPs2Gc4/VsnWdsMo5qYN3s9i4ZfdFqLwrXbl3vc1bRcLlENy+1yYS9Y1bVMF9iOPW+MQQXBUsuqFy3JK+yxWdyCO8M3TZingivlu3wHW0Lbg5Yio+WKjIBcGHVw+0AsHFp0VBOsf6D8wuI7vI+UiFQDqbF3bDKn38UQ2kM36Z5f1CV2iXuGh+9ZqhVsi/TbcCyEual8G6j/IRkM5y/+zeyyv8GFkpkE5n8dRKUa9FnyIrDdJZbp93HVGZ6igN0uk4T8oirVXRw/UqgnQ6pyfsK9Dtop3VAyCd8bbpQB8UjB0PgnQ6k12TVvGKnaFZBwgKKo2h+KeS5ngMJEJpItR7gnFgAyCogW1rnupWw0qN6mEQZPtVjZ2xtS8XOOoE6USnddZSLWpwKjB4ahIEVctb+GB3rE+vBc/IbRQEaf4WVq4X1bs+1KQy1QKCNF7sp+V75PXu9HhdJKoLJNLkaHuFW5nq71ZOmfRWoDpBIs2d1c5bc+tGd6fh9TipFveYqhsk1nLinK526PlryzVUNBzTddWwLH8a7LYr6mHEj+t/ZagUWVnAqjQAAAAASUVORK5CYII=" alt=""></div>
              <br>
              <div class="progress" style="height: 21px;">
                <div class="progress-bar bg-danger" role="progressbar" style="width: 45%" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100">45%</div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Certification part -->

  <div id="Certification" class="our-portfolio section">
    <div class="portfolio-left-dec">
      <img src="assets/images/portfolio-left-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2><em>Certificate</em><span></span></h2>
            <span>My Achivements</span>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-portfolio">
            <div class="item">
              
              <div class="thumb">
                <img src="HTML5.PNG" alt="">
                <div class="hover-effect">
                  <a rel="sponsored" href="https://templatemo.com/tm-564-plot-listing" target="_parent">
                  <div class="inner-content">
                      <h4>1. HTML5</h4></a>
                    <span>Infosys Springboard - HTML5</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="thumb">
                <img src="CSS3.png" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="https://templatemo.com/tm-564-plot-listing" target="_parent">
                      <h4>2. CSS</h4></a>
                    <span>Infosys Springboard - CSS3</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="thumb">
                <img src="JavaScript.png" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="https://templatemo.com/tm-564-plot-listing" target="_parent">
                      <h4>3. JavaScript </h4></a>
                    <span>Infosys Springboard - JavaScript</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="thumb">
                <img src="solo_learn_html.jpeg" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="https://templatemo.com/tm-564-plot-listing" target="_parent">
                      <h4>4. HTML</h4></a>
                    <span>Solo Learn - HTML</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="thumb">
                <img src="solo_learn_css.jpeg" alt="">
                <div class="hover-effect">
                  <div class="inner-content">
                    <a rel="sponsored" href="https://templatemo.com/tm-564-plot-listing" target="_parent">
                      <h4>5. Css</h4></a>
                    <span>Solo Learn - Css</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Tutorial part -->

  <div id="Tutorials" class="pricing-tables">
    <div class="tables-left-dec">
      <img src="assets/images/tables-left-dec.png" alt="">
    </div>
    <div class="tables-right-dec">
      <img src="assets/images/tables-right-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2><em>Tutorials</em></h2>
            <span>My Practice</span>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4">
          <div class="item first-item">
            <h4>Tutorial 1</h4>
              <div class="px-3 py-2">
                <img src="Tut-1.png" alt="">
                <hr>
                <div class="main-blue-button-hover py-1">
                  <a href="tutorial-1.zip" download>Download</a>
                </div>
                <div class="main-red-button-hover py-1">
                  <a href="tutorial-1\tutorial-1.html" target="_blank">Review</a>
                </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="item first-item">
            <h4>Tutorial 2</h4>
              <div class="px-3 py-2">
                <img src="Tut-2.png" alt="">
                <hr>
                <div class="main-blue-button-hover py-1">
                  <a href="tutorial-2.zip" download>Download</a>
                </div>
                <div class="main-red-button-hover py-1">
                  <a href="tutorial-2\tutorial-2_login.html" target="_blank">Review</a>
                </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="item first-item">
            <h4>Tutorial 3</h4>
              <div class="px-3 py-2">
                <img src="Tut-3.png" alt="">
                <hr>
                  <div class="main-blue-button-hover py-1">
                    <a href="#">Download</a>
                  </div>
                  <div class="main-red-button-hover py-1">
                    <a href="index.html" target="_blank">Review</a>
                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- projects part -->

  <div id="Projects" class="our-portfolio section">
    <div class="portfolio-left-dec">
      <img src="assets/images/portfolio-left-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading">
            <h2><em>Projects</em><span></span></h2>
            <span>Working Projects</span>
          </div>
        </div>
      </div>
    </div>
  <div id="video" class="our-videos section py-0 " >
    <div class="videos-left-dec">
      <img src="assets/images/videos-left-dec.png" alt="">
    </div>
    <div class="videos-right-dec">
      <img src="assets/images/videos-right-dec.png" alt="">
    </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-8">
                  <ul class="nacc">
                    <li class="active">
                      <div>
                        <div class="thumb">
                              <img class="image-radius" src="solo_learn_css.jpeg" alt="">

                          <!-- <iframe width="100%" height="auto" src="https://www.youtube.com/embed/JynGuQx4a1Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
                          <div class="overlay-effect">
                            <a href="#"><h4>CI  1  Project</h4></a>
                            <span>WEB_NAME</span>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div>
                        <div class="thumb">
                            <img class="image-radius" src="solo_learn_css.jpeg" alt="">
                          <!-- <iframe width="100%" height="auto" src="https://www.youtube.com/embed/JynGuQx4a1Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
                          <div class="overlay-effect">
                            <a href="#"><h4>CI 2 Project</h4></a>
                            <span>WEB_NAME</span>
                          </div>
                        </div>
                      </div>
                    <!-- </li>
                    <li>
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src="https://www.youtube.com/embed/ZlfAjbQiL78" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Project Three</h4></a>
                            <span>Digital &amp; Marketing</span>
                          </div>
                        </div>
                      </div>
                    </li> 
                    <li>
                      <div>
                        <div class="thumb">
                          <iframe width="100%" height="auto" src="https://www.youtube.com/embed/mx1WseE7-0Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                          <div class="overlay-effect">
                            <a href="#"><h4>Fourth Project</h4></a>
                            <span>SEO &amp; Advertising</span>
                          </div>
                        </div>
                      </div>
                    </li> -->
                  </ul>
                </div>
                <div class="col-lg-4">
                  <div class="menu">
                    <div class="active">
                      <div class="thumb">
                        <img class="image-radius" src="solo_learn_css.jpeg" alt="" >
                        <div class="inner-content">
                          <h4>CI  1  Project </h4>
                          <span>WEB_NAME</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="thumb">
                        <img class="image-radius" src="solo_learn_html.jpeg" alt="">
                        <div class="inner-content">
                          <h4>CI  2  Project</h4>
                          <span>WEB_NAME</span>
                        </div>
                      </div>
                    </div>
                    <div>
                      <!-- <div class="thumb">
                        <img src="assets/images/video-thumb-03.png" alt="Marketing">
                        <div class="inner-content">
                          <h4>Project Three</h4>
                          <span>Digital &amp; Marketing</span>
                        </div>
                      </div> -->
                    </div>
                    <!-- <div>
                      <div class="thumb">
                        <img src="assets/images/video-thumb-04.png" alt="SEO Work">
                        <div class="inner-content">
                          <h4>Fourth Project</h4>
                          <span>SEO &amp; Advertising</span>
                        </div>
                      </div>
                    </div> -->
                  </div>
                </div>             
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- contact me part -->

  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="section-heading">
            <h2>Feel free to <em>Contact</em> me via the <span>HTML form</span></h2>
            <div id="map">
              <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3692.9940857916117!2d70.89866591495371!3d22.24030318535473!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959b4a660019ee9%3A0x3d6254f36ed0e794!2sRK%20UNIVERSITY!5e0!3m2!1sen!2sin!4v1674130812184!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> -->
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3692.9940857916117!2d70.89866591495371!3d22.24030318535473!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959b4a660019ee9%3A0x3d6254f36ed0e794!2sRK%20UNIVERSITY!5e0!3m2!1sen!2sin!4v1674130812184!5m2!1sen!2sin"  width="100%" height="360px" frameborder="0" style="border:0" allowfullscreen=""></iframe>
              
              <!-- <iframe src="https://goo.gl/maps/SqS8zCj7rczgC4En9" width="100%" height="360px" frameborder="0" style="border:0" allowfullscreen=""></iframe> -->
            </div>
            <div class="info">
              <span><i class="fa fa-phone"></i> <a href="#">+91 7016926267 <br> +91 7016926267 </a></span>
              <span><i class="fa fa-envelope"></i> <a href="#">parthnagaraiya123@gmail.com<br>pnagariya789@rku.ac.in</a></span>
            </div>
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <form id="contact" action="submit.php" method="post">
            <div class="row">
              <div class="col-lg-12">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Name" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="surname" name="surname" id="surname" placeholder="Surname" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="website" id="website" placeholder="Your Website URL" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button">Submit Request</button>
                </fieldset>
              </div>
            </div>
          </form>
<?php 
$submit = false ;
if (($_SERVER)['REQUEST_METHOD'] == "POST")
{
    $user_name = $_POST['name'];
    $user_surname = $_POST['surname'];
    $user_email = $_POST['email'];
    $user_url = $_POST['website'];
    $submit = true ;
    if ($submit == true){
    echo '<div class="alert alert-warning" role="alert"> 
    YOUR RESONSE SUBMITTED SUCCESSFUL WE WILL CONTACT YOU SOON
    </div>'.'your info : '.$user_name ;}
    else {
        echo '<div class="alert alert-danger" role="alert"> 
    resubmit your response
    </div>' ;
    }
}


?>
        </div>
      </div>
    </div>
    <div class="contact-dec">
      <img src="assets/images/contact-dec.png" alt="">
    </div>
    <div class="contact-left-dec">
      <img src="assets/images/contact-left-dec.png" alt="">
    </div>
  </div>

  <div class="footer-dec">
    <img src="assets/images/footer-dec.png" alt="">
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
          <div class="about footer-item">
            <div class="logo">
              <a href="#"><img src="assets/images/logo.png" alt="Onix Digital TemplateMo"></a>
            </div>
            <a href="#">info@company.com</a>
            <ul>
              <li><a href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-behance"></i></a></li>
              <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="services footer-item">
            <h4>Services</h4>
            <ul>
              <li><a href="#">SEO Development</a></li>
              <li><a href="#">Business Growth</a></li>
              <li><a href="#">Social Media Managment</a></li>
              <li><a href="#">Website Optimization</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="community footer-item">
            <h4>Community</h4>
            <ul>
              <li><a href="#">Digital Marketing</a></li>
              <li><a href="#">Business Ideas</a></li>
              <li><a href="#">Website Checkup</a></li>
              <li><a href="#">Page Speed Test</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="subscribe-newsletters footer-item">
            <h4>Subscribe Newsletters</h4>
            <p>Get our latest news and ideas to your inbox</p>
            <form action="#" method="get">
              <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
              <button type="submit" id="form-submit" class="main-button "><i class="fa fa-paper-plane-o"></i></button>
            </form>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="copyright">
            <p>Copyright © 2021 All Rights Reserved. 
            <br>
            Designed by <a rel="nofollow" href="https://templatemo.com" title="free CSS templates">TemplateMo</a></p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
  </script>
</body>
</html>