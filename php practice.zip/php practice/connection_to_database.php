<?php
echo 'THIS IS SEQL';
// way to connect with mysql
//1. MySQLi extention
    //a) procedural way (function)
    //2. PDO (php data objects )
    //b) object orrieanted way (class and object) 
    
//this is require for connecting to database

$servername="localhost";
$username="root";
$password="";
$dbname = "grocerycustomer";
//$password="1234"; we fill password to this empty string it gives error and run this if else code

//create a connection 
$conn = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn)
{
    die("sorry we can't connect you to server" . mysqli_connect_error());
}
else
{
    // echo "Connection was successful";
}

//create database
// $sql ="CREATE DATABASE databasename"; this create database with name in php admin database
// mysqli_query($conn,$sql);

?>