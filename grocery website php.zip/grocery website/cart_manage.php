<?php
session_start();
// session_destroy();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['Add_to_cart'])) {
        if (isset($_SESSION['cart'])) {
            $mypro =  array_column($_SESSION['cart'], 'product_name');
            if (in_array($_POST['product_name'], $mypro)) {
                echo "<script>
                alert('Product Already Added')
                window.location.href('cart.php');
                </script>";
            } else {
                $count = count($_SESSION['cart']);
                $_SESSION['cart'][$count] = array(
                    'product_name' => $_POST['product_name'],
                     'product_quantity' => 1, 
                    'product_price' => $_POST['product_price']
                );
                echo "<script>
            alert('Product Added')
            window.location.href('cart.php');
            </script>";
            }
        } else {
            $_SESSION['cart'][0] = array(
                'product_name' => $_POST['product_name'],
                'product_quantity' => 1,
                'product_price' => $_POST['product_price']
            );
            echo "<script>
                alert('Product Added')
                window.location.href('cart.php');
                </script>";
        }
    }
    if(isset($_POST['remove_product']))
    {
        foreach($_SESSION['cart'] as $key => $value)
        {
            if($value['product_name'] == $_POST['product_name']){
                unset($_SESSION['cart'][$key]);
                $_SESSION['cart']=array_values($_SESSION['cart']);
                echo '<script>
                alert("Item Removed")
                window.location.href = "cart_manage.php";
                </script>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart | Purchase </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <style>
            .contact form {
            text-align: center;
            padding: 1px;
            text-decoration: none;
            border: 2px solid white;
            justify-content: center;
        }

        .contact form .inputBox {
            display: block;
            justify-content: center;
            flex-wrap: none;
        }


        .contact form .inputBox input {
            padding: 1rem;
            font-size: 1.7rem;
            background: #f7f7f7;
            text-transform: none;
            margin: 1rem 0;
            width: 49%;
        }

        .contact form .inputBox input:hover {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .contact .mytext p {
            font-family: 'Nunito', sans-serif;
            font-weight: 400;
            padding-top: 5px;
        }

        .contact .mytext a {
            font-size: 15px;
            text-decoration: none;
            color: #27ae60;
        }

        label {
            display: block;
            padding-top: 2px;
            font-size: 15px;
            color: red;
        }
        </style>
</head>

<body>

    <!-- header section starts  -->

    <header>

        <div class="header-1">

            <a href="index.php" class="logo" style="text-decoration: none;">GroMart</a>

            <form action="" class="search-box-container">
                <input type="search" id="search-box" placeholder="search here">
                <label for="search-box" class="fas fa-search"></label>
            </form>

        </div>

        <div class="header-2">

            <div id="menu-bar" class="fas fa-bars"></div>

            <nav class="navbar" >
                <a href="index.php" style="text-decoration: none;">home</a>
                <a href="category.php" style="text-decoration: none;">Products</a>
            </nav>

            <div class="icons">
                <a href="cart_manage.php" style="text-decoration: none;" class="fas fa-shopping-cart"></a>
            </div>

        </div>

    </header>

    <section class="product" id="product">

        <h1 class="heading"><span> Product in</span> cart<span> </span></h1>

        <table class="table">
  <thead class="text-center">
    <tr style="font-size: 20px;">
      <th scope="col">Product Name</th>
      <th scope="col">Product Price</th>
      <th scope="col">Product Quantity</th>
      <th scop="col">Updates</th>
    </tr>
  </thead>
  <tbody class="text-center" style="font-size : 18px" ;>
  <?php
  $total=0;
if(isset($_SESSION['cart'])){
foreach($_SESSION['cart'] as $key => $value)
  {
    $total+=$value['product_price'];
    echo "
    <tr>
    <td>$value[product_name]</td>
    <td>$value[product_price]</td>
    <td><input class='text-center' type='number' value='$value[product_quantity]' min='1' max='20'></td>
    <td>
    <form action='cart_manage.php' method='post'>
    <button name='remove_product' class='btn btn-danger'>Remove</button>
    <input type='hidden' name='product_name' value='$value[product_name]'>
    </form>
    </td>
    </tr>
    ";
  }
}

  ?>  
    
  </tbody>
</table>

    </section>
<section class="contact">

    <div class="container text-center" style="font-size: 18px;" >
        <?php
        echo "<p style='color : green ;'>Total Ammount : <span style='color : black'>$total</span> </p>" ;
        ?>
        
        <form action="cart_manage.php" method="post">
        <div class="inputBox">
                <input type="text" id="mobile" name="user_mobile" placeholder="mobile">
                <label id="mobile_error">

                </label>
        </div>
        <?php 
                        // error_reporting(0);
        
                $sname = "localhost";
                $uname = "root";
                $password = "";
                $db_name = "grocerycustomer";
                $alert = false ; 

                $random = uniqid().chr(mt_rand(65, 90)).mt_rand(1, 1000).uniqid();;
                $conn = mysqli_connect($sname, $uname, $password, $db_name);
                if (!$conn) {
                    die("sorry we can't connect you to server" . mysqli_connect_error());
                }
                else
                 {
                    if (isset($_POST['payment'])) {
                        $user_mobile = $_POST['user_mobile'];
                        
                    foreach ($_SESSION['cart'] as $key => $value) {
                        $product_name = $value['product_name'];
                        $product_price  = $value['product_price'];
                        $product_quantity = $value['product_quantity'];
                        // 	product_quantity	user_mobile	product_name	order_id
                        $insert = "INSERT INTO `order` (`product_quantity`,`user_mobile`,`product_name` , `order_id` , `product_price`)
                        VALUES ('$product_quantity','$user_mobile',' $product_name ','$random','$product_price')";
                        $result = mysqli_query($conn , $insert);
                        if($result)
                        {
                            $alert = true ; 
                        }
                    }
                    if($alert){
                        $insert2 = "INSERT INTO `revenue` (`user_mobile`,`total_ammount`) VALUES ('$user_mobile','$total')";
                        $result = mysqli_query($conn , $insert2);
                    echo '
                            <div class="alert alert-success" role="alert">
                              <h4 class="alert-heading">Well done Payment Successfully completed !</h4>
                              <p>we glad to know you purchase food from our website. Your health is our first responsiblity. </p>
                              <hr>
                              <p class="mb-0">Eat Good Feel Good</p>
                            </div>
                            ';
                 }           
            }
        }
            ?>
        <button class="btn-lg btn-success" name="payment" type="submit">Payment</button>
        <form>

    </div>
</section>
    <script>
        $(document).ready(function() {
            // Validate fields on input
            $('#mobile').on('input', validateMobile);

            // Validate all fields before submitting form
            $('form').submit(function(event) {
                var valid = true;
                if (!validateMobile()) {
                    valid = false;
                }
                if (!valid) {
                    event.preventDefault();
                }
            });

            function validateMobile() {
                var mobile = $('#mobile').val();
                if (!/^\d{10}$/.test(mobile)) {
                    $('#mobile_error').text('Mobile number must be 10 digits');
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#mobile_error').text('');
                    $("#mobile").css({
                        "box-shadow": "none"
                    });
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 , 0 , 0.5)"
                    });
                    return true;
                }
            }

           
        });
    </script>
</body>

</html>