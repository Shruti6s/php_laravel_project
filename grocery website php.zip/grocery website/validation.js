// $(document).ready(function () {
//   $("#myform").submit(function (event) {
//     var password = $("#password").val();
//     var mobile = $("#mobile").val();
//     var check = false;
//     var emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

//     if (!mobile) {
//       $("#mobile").css({"box-shadow":   "0 0 10px rgba(255, 0, 0, 0.7)"});
//       check = false;
//     } else if (mobile.length != 10) {
//       $("#mobile").addClass("w3-border-red");
//       check = false;
//     } else if (!password) {
//       $("#password").addClass("w3-border-red");
//       check = false;
//     } else if (password.length < 8) {
//       $("#password").addClass("w3-border-red");
//       check = false;
//     } else if (!password.match(/[a-zA-z]/)) {
//       $("#password").addClass("w3-border-red");
//       check = false;
//     } else {
//       $("#mobile").removeClass("w3-border-red");
//       $("#password").removeClass("w3-border-red");
//       check = true;
//     }

//     if (check == false) {
//       event.preventDefault();
//     }
//   });
// });


// $(document).ready(function() {
//   $("#myform").submit(function(event) {
//       var email = $("#email").val();
//       var password = $("#password").val();
//       var mobile = $("#mobile").val();
//       var user = $("#name").val();
//       var check = false;
//       var re = /\S+@\S+\.\S+/;
//       if (!mobile) {
//           $("#mobile").css({
//               "box-shadow": "0 0 10px rgba(255, 0, 0, 0.7)"
//           });
//           $("#mobile_error").text("Mobile number is required !");
//       } 
//       else {
//           if (mobile.length != 10) {
//               $("#mobile").css({
//                   "box-shadow": "0 0 10px rgba(255, 0, 0, 0.7)"
//               });
//               $("#mobile_error").text("Mobile number length should be 10 only !");
//           }
//           else 
//           {
//               $("#mobile").css({
//                   "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"
//               });
//               $("#mobile_error ").text("");
//           }
//       } 
      

//       if (!password) {
//           $("#mobile").css({
//               "box-shadow": "0 0 10px rgba(255, 0, 0, 0.7)"
//           });
//           $("#password_error").text("Password is required !");
//           check = false;
//       } else {
//           $("#password").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"
//           });
//           $("#password_error ").text("");
//           check = true;
//       }
//       if (password.length < 8) {
//           $("#password_error").text("Password lenght should be 8 or more !");
//           $("#password").css({
//               "box-shadow": "0 0 10px rgba(255, 0, 0, 0.7)"
//           });
//           check = false;
//       } else {
//           $("#password").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"
//           });
//           $("#password_error ").text("");
//           check = true;
//       }
//       if (!password.match(/[a-zA-z]/)) {
//           $("#password").css({
//               "box-shadow": "0 0 10px rgba(255, 0, 0, 0.7)"
//           });
//           $("#password_error").text("Password must contain 1 alphabet !");
//           check = false;
//       } else {
//           $("#password").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"
//           });
//           $("#password_error ").text("");
//           check = true;
//       }
//       if (!email) {
//           $("#email").css({
//               "box-shadow": "0 0 10px rgba(255 , 0 , 0 , 0.7)"
//           });
//           $("#email_error").text("Email is required !");
//           check = false;
//       } else {
//           $("#email").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"

//           });
//           $("#email_error").text("");
//           check = true;
//       }
//       if (!(re.test(email))) {
//           $("#email").css({
//               "box-shadow": "0 0 10px rgba(255 , 0 , 0 , 0.7)"
//           });
//           $("#email_error").text("Enter valid email !");
//           check = false;
//       } else {
//           $("#email").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"

//           });
//           $("#email_error").text("");
//           check = true;
//       }
//       if (!user) {
//           $("#name").css({
//               "box-shadow": "0 0 10px rgba(255 , 0 , 0 , 0.7)"
//           });
//           $("#name_error").text("User name required !");
//           check = false;
//       } else {
//           $("#name").css({
//               "box-shadow": "0 0 10px rgba(0 , 0 , 255 , 0.7)"
//           });
//           $("#name_error").text("");
//           check = true;
//       }
//       if (check == false) {
//           event.preventDefault();
//       }
//   });
// });