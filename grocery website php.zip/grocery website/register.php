<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Page</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--  css file link  -->
    <link rel="stylesheet" href="style.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- jQuery UI -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>

    <style>
        .btn {
            display: inline-block;
            margin-top: 1rem;
            background: linear-gradient(to right, rgb(45, 180, 27), #2c2c54);
            
            color: #fff;
            border-radius: 20px 0 20px 0;
            padding: .8rem 3rem;
            font-size: 1.7rem;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            transition: all .9s linear;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
            border-radius: 0 20px 0 20px;
            color : white ;
        }
        
        .contact form {
            text-align: center;
            padding: 2rem;
            text-decoration: none;
            border: 2px solid white;
            justify-content: center;
        }

        .contact form .inputBox {
            display: block;
            justify-content: center;
            flex-wrap: none;
        }


        .contact form .inputBox input {
            padding: 1rem;
            font-size: 1.7rem;
            background: #f7f7f7;
            text-transform: none;
            margin: 1rem 0;
            width: 49%;
        }

        .contact form .inputBox input:hover {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .contact .mytext p {
            font-family: 'Nunito', sans-serif;
            font-weight: 400;
            padding-top: 5px;
        }

        .contact .mytext a {
            font-size: 15px;
            text-decoration: none;
            color: #27ae60;
        }

        label {
            display: block;
            padding-top: 2px;
            font-size: 15px;
            color: red;
        }



    </style>
</head>

<body>
    <?php
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $db_name = "grocerycustomer";
    $conn = mysqli_connect($sname, $uname, $password, $db_name);
    if (!$conn) {
        die("sorry we can't connect you to server" . mysqli_connect_error());
    } else {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $user_name = $_POST['user_name'];
            $user_mail = $_POST['user_mail'];
            $user_mobile = $_POST['user_mobile'];
            $user_password = $_POST['user_password'];
            $getdata = "SELECT * FROM `register_user` WHERE `user_mobile` = '$user_mobile' ";
            $result = mysqli_query($conn, $getdata);
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    echo '
                    <div class="alert alert-warning  alert-dismissible fade show" role="alert">
                    <h4>User Already Exist! 
                    <a class="mb-0" href="login.php"> Click Here To Login </a>
                    </h4> 
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    ';
                } else {
                    $query = "INSERT INTO `register_user` (`user_mobile`,`user_email`,`user_password`, `user_name`)
                    VALUES('$user_mobile','$user_mail','$user_password','$user_name')";
                    mysqli_query($conn, $query);
                    echo '

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <h4>Register Scuccessfully Completed!  
                    <a class="mb-0" href="register.php"> Click Here To Login </a>
                    </h4> 
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    ';
                }
            }
        }
    }

    ?>
    <header>
        <div class="header-1">
        <a href="index.php" class="logo" style="text-decoration: none;"><i class="fas fa-shopping-basket" ></i>GroMart</a>    
        <!-- <a style="text-decoration: none;" href="index.php" class="logo">GroMart</a> -->
            <h1>Register Form</h1>
        </div>
    </header>

    <section class="contact" id="contact">

        <h1 class="heading"> <span>Register </span> here</h1>

        <form action="register.php" method="post" id="myform">

            <div class="inputBox">
                <input id="name" type="text" name="user_name" placeholder="Enter Your Name">
                <label id="name_error">

                </label>
            </div>
            <div class="inputBox">
                <input id="password" type="password" name="user_password" placeholder="Enter Password">
                <label id="password_error">

                </label>
            </div>

            <div class="inputBox">
                <input id="mobile" type="text" name="user_mobile" placeholder="Enter Your Mobile" maxlength="10">
                <label id="mobile_error">

                </label>
            </div>
            <div class="inputBox">
                <input id="email" type="email" name="user_mail" placeholder="Enter Your Email">
                <label id="email_error">

                </label>
            </div>

            <input type="submit" value="Sign Up" class="btn" style="margin : 8px;">
            <input type="reset" value="Reset" class="btn" style="margin: 8px;">

        </form>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Already account ? <a style="text-decoration: none;" href="login.php"> Login </a></p>
        </div>
    </section>

    <script>
        $(document).ready(function() {
            // Validate fields on input
            $('#name').on('input', validateUsername);
            $('#password').on('input', validatePassword);
            $('#email').on('input', validateEmail);
            $('#mobile').on('input', validateMobile);

            // Validate all fields before submitting form
            $('form').reset(function(event) {

            });
            $('form').submit(function(event) {
                var valid = true;
                if (!validateUsername()) {
                    valid = false;
                }
                if (!validatePassword()) {
                    valid = false;
                }
                if (!validateEmail()) {
                    valid = false;
                }
                if (!validateMobile()) {
                    valid = false;
                }
                if (!valid) {
                    event.preventDefault();
                }
            });

            // Validation functions
            function validateUsername() {
                var username = $('#name').val();
                if (username.length < 3) {
                    $('#name_error').text('Username must be at least 3 characters long');
                    $("#name").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#name_error').text('');
                    $("#name").css({
                        "box-shadow": "none"
                    });
                    $("#name").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 , 0, 0.5)"
                    });
                    return true;
                }
            }

            function validatePassword() {
                var password = $('#password').val();
                if (password.length < 8) {
                    $('#password_error').text('Password must be at least 8 characters long');
                    $("#password").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#password_error').text('');
                    $("#password").css({
                        "box-shadow": "none"
                    });
                    $("#password").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 ,0 , 0.5)"
                    });
                    return true;
                }
            }

            function validateEmail() {
                var email = $('#email').val();
                if (!/^\S+@\S+\.\S+$/.test(email)) {
                    $('#email_error').text('Invalid email address');
                    $("#email").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#email_error').text('');
                    $("#email").css({
                        "box-shadow": "none"
                    });
                    $("#email").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 , 0 , 0.5)"
                    });
                    return true;
                }
            }

            function validateMobile() {
                var mobile = $('#mobile').val();
                if (!/^\d{10}$/.test(mobile)) {
                    $('#mobile_error').text('Mobile number must be 10 digits');
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#mobile_error').text('');
                    $("#mobile").css({
                        "box-shadow": "none"
                    });
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 , 0 , 0.5)"
                    });
                    return true;
                }
            }
        });
    </script>

</body>

</html>