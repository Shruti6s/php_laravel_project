<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vegetables | Catagory </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="style.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<style>
    .btn {
            display: inline-block;
            margin-top: 1rem;
            background: linear-gradient(to right, rgb(45, 180, 27), #2c2c54);
            
            color: #fff;
            border-radius: 20px 0 20px 0;
            padding: .8rem 3rem;
            font-size: 1.7rem;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            transition: all .9s linear;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
            border-radius: 0 20px 0 20px;
            color : white ;
        }

</style>
</head>

<body>

<!-- header section starts  -->

<header>

    <div class="header-1">

        <a href="index.php" class="logo">GroMart</a>

        <form action="" class="search-box-container">
            <input type="search" id="search-box" placeholder="search here">
            <label for="search-box" class="fas fa-search"></label>
        </form>

    </div>

    <div class="header-2">

        <div id="menu-bar" class="fas fa-bars"></div>

        <nav class="navbar">
            <a href="#index.php">home</a>
            <a href="#index.php">category</a>
        </nav>

        <!-- <div class="icons">
            <a href="#" class="fas fa-shopping-cart"></a>
        </div> -->

    </div>

</header>

<section class="product" id="product">
    <h1 class="heading"><span> Likable </span> Product</h1>
</section>


<?php
session_start();

// Get the cart information from the session
$cart = isset($_SESSION["cart"]) ? $_SESSION["cart"] : array();

// Loop through the cart and display each product's information
foreach ($cart as $product) {
    echo "Product Name: " . $product["product_name"] . "<br>";
    echo "Quantity: " . $product["quantity"] . "<br>";
    echo "Price: $" . $product["product_price"] . "<br>";
    echo "<br>";
}
?>
<!-- footer section ends -->
<!-- custom js file link  -->
<!-- 
<script>
    $(document).ready(function () {
        $(".btn").css("color", "white");
        $(".btn").css("cursor", "pointer");
        $(".btn").css(
            "background",
            "to right , rgb(255, 0, 247), rgba(38, 255, 0)"
        );
        
    });

    $(document).ready(function () {
        $(".btn").hover(function () {
            $(".btn").css(
            "background",
            "to right , rgb(255, 0, 247), rgba(38, 255, 0)"
        );
        });
    });
</script> -->
</body>
</html>