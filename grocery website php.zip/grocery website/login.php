<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Page</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--  css file link  -->
    <link rel="stylesheet" href="style.css">

    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery UI -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.1/themes/smoothness/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.1/jquery-ui.min.js"></script>
    <style>
        .btn {
            display: inline-block;
            margin-top: 1rem;
            background: linear-gradient(to right, rgb(45, 180, 27), #2c2c54);

            color: #fff;
            border-radius: 20px 0 20px 0;
            padding: .8rem 3rem;
            font-size: 1.7rem;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            transition: all .9s linear;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
            border-radius: 0 20px 0 20px;
            color: white;
        }

        .contact form {
            text-align: center;
            padding: 2rem;
            text-decoration: none;
            border: 2px solid white;
            justify-content: center;
        }

        .contact form .inputBox {
            display: block;
            justify-content: center;
            flex-wrap: none;
        }


        .contact form .inputBox input {
            padding: 1rem;
            font-size: 1.7rem;
            background: #f7f7f7;
            text-transform: none;
            margin: 1rem 0;
            width: 49%;
        }

        .contact form .inputBox input:hover {
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }

        .contact .mytext p {
            font-family: 'Nunito', sans-serif;
            font-weight: 400;
            padding-top: 5px;
        }

        .contact .mytext a {
            font-size: 15px;
            text-decoration: none;
            color: #27ae60;
        }

        label {
            display: block;
            padding-top: 2px;
            font-size: 15px;
            color: red;
        }
    </style>
</head>

<body>

    <?php
    // session_start();
    // session_destroy();
    $sname = "localhost";
    $uname = "root";
    $password = "";
    $login = false ; 
    $db_name = "grocerycustomer";
    $conn = mysqli_connect($sname, $uname, $password, $db_name);
    if (!$conn) {
        die("sorry we can't connect you to server" . mysqli_connect_error());
    } else {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $user_mobile = $_POST['user_mobile'];
            $user_password = $_POST['user_password'];
            $getdata = "SELECT * FROM `register_user` WHERE `user_mobile` = '$user_mobile' and `user_password` = '$user_password' ";
            $result = mysqli_query($conn, $getdata);

            if (mysqli_num_rows($result) > 0) {
                $login = true ; 
                if($login)
                {
                    session_start();
                    $get_email = "SELECT `user_email` FROM `register_user` WHERE `user_mobile` = '$user_mobile'";
                    $object = mysqli_query($conn, $get_email);
                    $row = mysqli_fetch_assoc($object);
                    $_SESSION['email'] = $row["user_email"];
                    $_SESSION['login'] = $login;
                    echo '<script>window.location.href = "index.php"</script>';
                }
            } else {
                $login = false ; 
                echo '
                <div class="alert alert-danger  alert-dismissible fade show" role="alert">
                    <h4>Enter currect mobile number and password !
                    <a class="mb-0" href="register.php"> Check Your Account </a>
                    </h4> 
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                ';
            }
        }
    }
    ?>

    <header>
        <div class="header-1">
            <a style="text-decoration: none" href="index.php" class="logo">GroMart</a>
            <h1>login</h1>
        </div>
    </header>


    <section class="contact" id="contact">

        <h1 class="heading"> <span>Login</span> here </h1>

        <form action="login.php" id="myform" method="post">

            <div class="inputBox">
                <input type="text" id="mobile" name="user_mobile" placeholder="mobile">
                <label id="mobile_error">

                </label>
            </div>
            <div class="inputBox">
                <input type="password" id="password" name="user_password" placeholder="password">
                <label id="password_error">

                </label>
            </div>
            <input type="submit" value="Login" class="btn">

        </form>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Forget Password ? <a style="text-decoration: none;" href="reset_password.php"> Reset </a></p>
        </div>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Create New Account ? <a style="text-decoration: none;" href="register.php"> Register </a></p>
        </div>
    </section>

    <script>
        $(document).ready(function() {
            // Validate fields on input
            $('#password').on('input', validatePassword);
            $('#mobile').on('input', validateMobile);

            // Validate all fields before submitting form
            $('form').submit(function(event) {
                var valid = true;
                if (!validatePassword()) {
                    valid = false;
                }
                if (!validateMobile()) {
                    valid = false;
                }
                if (!valid) {
                    event.preventDefault();
                }
            });

            function validateMobile() {
                var mobile = $('#mobile').val();
                if (!/^\d{10}$/.test(mobile)) {
                    $('#mobile_error').text('Mobile number must be 10 digits');
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#mobile_error').text('');
                    $("#mobile").css({
                        "box-shadow": "none"
                    });
                    $("#mobile").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 , 0 , 0.5)"
                    });
                    return true;
                }
            }

            function validatePassword() {
                var password = $('#password').val();
                if (password.length < 8) {
                    $('#password_error').text('Password must be at least 8 characters long');
                    $("#password").css({
                        "box-shadow": "0 0 10px rgba(255,0,0,0.5)"
                    });
                    return false;
                } else {
                    $('#password_error').text('');
                    $("#password").css({
                        "box-shadow": "none"
                    });
                    $("#password").css({
                        "box-shadow": "0 0 10px rgba(0 , 255 ,0 , 0.5)"
                    });
                    return true;
                }
            }
        });
    </script>



</body>

</html>