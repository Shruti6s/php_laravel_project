<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class reset_password_validate extends Controller
{
    public function val(Request $request)
    {
        $request->validate([
            'user_mobile' => 'required',
            'user_repassword' => 'required',
            'user_password' => 'required'
        ]);

        $user_mobile = $request->user_mobile;
        $new_password = $request->user_password;
        $original_password = $request->user_repassword;

        if ($new_password != $original_password) {
            return redirect('/reset_password')->with('error', 'Passwords do not match.');
        }

        $user = DB::table('register')->where('user_mobile', $user_mobile)->first();

        if ($user) {
            $x = DB::table('register')->where('user_mobile', $user_mobile)
                ->update(['user_password' => $new_password]);
            if ($x){
                return redirect('login');
            }
        }
        else {
            return redirect('register');
        }
        
    }
}
