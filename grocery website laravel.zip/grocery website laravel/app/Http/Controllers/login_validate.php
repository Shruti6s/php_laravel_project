<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class login_validate extends Controller
{
    public function val(Request $request)
    {
        $request->validate([
            'user_mobile' => 'required',
            'user_password' => 'required'
        ]);
        
        $user_mobile = $request->user_mobile ;
        $user_password = $request->user_password ;
        $check = DB::table('register')->where([
            ['user_mobile' , '=' , $user_mobile],
            ['user_password' , '=' , $user_password]
        ])->get();

        if($check->isEmpty()){
            return redirect('/register');  
        }
        else {
            $request->session()->put('user_mobile', $request->user_mobile);
            return redirect('/home');
        }
    }

   
}

