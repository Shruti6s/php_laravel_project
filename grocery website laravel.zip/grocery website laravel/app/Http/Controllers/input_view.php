<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class input_view extends Controller
{
    public function Index()
    {
        return view('index') ; 
    }
    public function login()
    {
        return view('login');
    }
    public function category()
    {
        return view('category') ; 
    }
    public function register()
    {
        return view('register');
    }
    public function reset_password()
    {
        return view("reset_password");
    }
    
    // public function reset_password_data(Request $request)
    // {
    //     $request->validate([
    //         'user_mobile' => 'required|mobile',
    //         'user_password' => 'required|password',
    //         'user_repassword' => 'required|password'
    //     ]);
    // }

    // public function login_data(Request $request)
    // {
    //     $request->validate([
    //         'user_mobile' => 'required|mobile',
    //         'user_password' => 'required|password'
    //     ]);
    // }
    // public function register_data(Request $request)
    // {
        
    // }

}

