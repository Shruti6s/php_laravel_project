<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; 
use App\Models\register ;


class register_validate extends Controller
{
    public function val(Request $request)
    {
        $request->validate([
            'user_name' => 'required' ,
            'user_mail' => 'required' ,
            'user_mobile' => 'required',
            'user_password' => 'required'
        ]);

        $obj = new register();
        $obj->user_name = $request['user_name']; 
        $obj->user_email = $request['user_mail'];
        $obj->user_mobile = $request['user_mobile'];
        $obj->user_password = $request['user_password'];
        if ($obj->save()) {
            return view('login');
        }
        else {
            return view('register');
        }
    }    
}
