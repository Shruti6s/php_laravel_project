<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\input_view;
use App\Http\Controllers\login_validate;
use App\Http\Controllers\register_validate;
use App\Http\Controllers\reset_password_validate;
use App\Http\Controllers\SingleAction;
use Illuminate\Auth\Events\Login;
// use App\Models\register;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/{marks?}', function ($marks = null) {
//     $data = compact('marks');

//     return view('if_2')->with($data);
// });


// Route::get('/{num?}', function ($num = null) {
//     $data = compact('num');
//     return view('even_odd')->with($data);
// });

// Route::get('/{name?}', function ($name = null) {
//     $data = compact('name');
//     return view('unless_endunless')->with($data);
// });


// Route::get('/', function () {
//     return view('for_loop');
// });

Route :: get('/home', [input_view :: class,'Index']);
Route :: get('', [input_view :: class,'Index']);
Route :: get('/', [input_view :: class,'Index']);

Route :: get('/login', [input_view :: class,'login']);
Route :: get('/register', [input_view :: class,'register']);
Route :: get('/reset_password', [input_view :: class,'reset_password']);

Route :: post('/login', [login_validate :: class,'val']);
Route :: post('/register', [register_validate :: class,'val']);
Route :: post('/reset_password', [reset_password_validate :: class,'val']);

Route :: get('/category' , SingleAction :: class);
// Route :: get('/category', [input_view::class,'category']);

Route :: post('/' , [login_validate :: class , 'destroy']);


Route::view('/prime', "prime_number");
