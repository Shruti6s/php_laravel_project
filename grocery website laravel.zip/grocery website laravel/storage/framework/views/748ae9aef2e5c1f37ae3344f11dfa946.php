<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>if else</title>
</head>
<body>
    <?php if (! ($name == 'Laravel')): ?>
    <div class='text-danger h2'>
        Pls choose laravel.
    </div>
    <?php endif; ?>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\first_laravel_project\resources\views/unless_endunless.blade.php ENDPATH**/ ?>