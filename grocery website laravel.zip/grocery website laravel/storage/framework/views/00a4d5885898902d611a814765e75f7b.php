<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<body>
    <?php echo $__env->make('layouts.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <section class="contact" id="contact">

        <h1 class="heading"> <span>Register </span> here</h1>

        <form action="<?php echo e(url('/')); ?>/register" method="post" id="myform">
            <?php echo csrf_field(); ?>
            <div class="inputBox">
                <input id="name" type="text" name="user_name" placeholder="Enter Your Name">
                <label id="name_error">
                    <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
            <div class="inputBox">
                <input id="password" type="password" name="user_password" placeholder="Enter Password">
                <label id="password_error">
                    <?php $__errorArgs = ['user_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>

            <div class="inputBox">
                <input id="mobile" type="text" name="user_mobile" placeholder="Enter Your Mobile" maxlength="10">
                <label id="mobile_error">
                    <?php $__errorArgs = ['user_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
            <div class="inputBox">
                <input id="email" type="email" name="user_mail" placeholder="Enter Your Email">
                <label id="email_error">
                    <?php $__errorArgs = ['user_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>

            <input type="submit" value="Sign Up" class="btn" style="margin : 8px;">
            <input type="reset" value="Reset" class="btn" style="margin: 8px;">

        </form>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Already account ? <a style="text-decoration: none;" href="<?php echo e('/login'); ?>"> Login </a></p>
        </div>
    </section>

    
</body>

</html><?php /**PATH C:\xampp\htdocs\first_laravel_project\resources\views/register.blade.php ENDPATH**/ ?>