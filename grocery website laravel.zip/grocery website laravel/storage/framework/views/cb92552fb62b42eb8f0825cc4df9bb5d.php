<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<body>
    <?php echo $__env->make('layouts.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <section class="contact" id="contact">

        <h1 class="heading"> <span>Reset</span> Password </h1>

        <form action="<?php echo e(url('/')); ?>/reset_password" id="myform" method="post">
            <?php echo csrf_field(); ?>
            <div class="inputBox">
                <input type="text" id="mobile" name="user_mobile" placeholder="Mobile">
                <label id="mobile_error">
                    <?php $__errorArgs = ['user_mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>

            <div class="inputBox">
                <input type="password" id="password" name="user_password" placeholder="Password">
                <label id="password_error">
                    <?php $__errorArgs = ['user_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
            <div class="inputBox">
                <input type="password" id="repassword" name="user_repassword" placeholder="Final Password">
                <label id="repassword_error">
                    <?php $__errorArgs = ['user_repassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>
            <input type="submit" value="Reset Password" class="btn">
        </form>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\first_laravel_project\resources\views/reset_password.blade.php ENDPATH**/ ?>