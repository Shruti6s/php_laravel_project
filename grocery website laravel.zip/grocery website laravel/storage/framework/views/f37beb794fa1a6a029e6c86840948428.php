<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>if else</title>
</head>
<body>
    <?php if($marks >=33): ?>
    <div class='text-success h2'>
        Student is pass.
    </div>
    <?php else: ?>
    <div class='text-danger h2'>
        Student failed.
    </div>
    <?php endif; ?>    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\first_laravel_project\resources\views/if_2.blade.php ENDPATH**/ ?>