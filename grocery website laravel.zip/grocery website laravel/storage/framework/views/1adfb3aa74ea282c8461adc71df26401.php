<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vegetables | Catagory </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/style.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style>
        .btn {
            display: inline-block;
            margin-top: 1rem;
            background: linear-gradient(to right, rgb(45, 180, 27), #2c2c54);

            color: #fff;
            border-radius: 20px 0 20px 0;
            padding: .8rem 3rem;
            font-size: 1.7rem;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            transition: all .9s linear;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
            border-radius: 0 20px 0 20px;
            color: white;
        }
    </style>
</head>

<body>

    <!-- header section starts  -->

    <header>

        <div class="header-1">
        <a href="<?php echo e(url('/')); ?>" class="logo" style="text-decoration: none ; "><i class="fas fa-shopping-basket"></i>GroMart</a>
            <form action="" class="search-box-container">
                <input type="search" id="search-box" placeholder="search here">
                <label for="search-box" class="fas fa-search"></label>
            </form>

        </div>

        <div class="header-2">

            <div id="menu-bar" class="fas fa-bars"></div>

            <nav class="navbar">
                <a href="<?php echo e('/'); ?>">home</a>
                <a href="<?php echo e('/'); ?>">category</a>
                <a href="cart_manage.php">Cart</a>
            </nav>

            <div class="icons">
                <a href="cart_manage.php" class="fas fa-shopping-cart"></a>
            </div>

        </div>

    </header>

    <section class="product" id="product">

        <h1 class="heading"><span> latest </span>vegitable <span> products</span></h1>

        <div class="box-container">

            <div class="box">
                <span class="discount">-45%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/tomato.png" alt="">
                <h3>organic tomato</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 30.50 <span> ₹ 40.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Tomato">
                    <input type="hidden" name="product_price" value="30.50">
                    <button type="submit" name="Add_to_cart" class="btn">add to cart</button>
                </form>

            </div>

            <div class="box">
                <span class="discount">-40%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/carrot.png" alt="">
                <h3>organic carrot</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 70.50 <span> ₹ 93.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Carrot">
                    <input type="hidden" name="product_price" value="70.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

            <div class="box">
                <span class="discount">-40%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/potato.jpg" alt="">
                <h3>organic potato</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 55.50 <span> ₹ 80.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Potato">
                    <input type="hidden" name="product_price" value="55.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

        </div>

    </section>

    <section class="product" id="product">

        <h1 class="heading"><span> latest </span> fruit <span> products</span></h1>

        <div class="box-container">

            <div class="box">
                <span class="discount">-33%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>

                <img src="../img/banana.png" alt="">
                <h3>organic banana</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 10.50 <span> ₹ 13.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Banana">
                    <input type="hidden" name="product_price" value="10.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>


            <div class="box">
                <span class="discount">-52%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/orange.png" alt="">
                <h3>organic orange</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 100.50 <span> ₹ 113.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Orange">
                    <input type="hidden" name="product_price" value="100.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

            <div class="box">
                <span class="discount">-20%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/blackbarry.png" alt="">
                <h3>organic grapes</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price">₹ 95.70 <span> ₹ 130.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Grapes">
                    <input type="hidden" name="product_price" value="95.75">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>
        </div>

    </section>


    <section class="product" id="product">

        <h1 class="heading"><span> latest </span> milk<span> products</span></h1>

        <div class="box-container">
            <div class="box">
                <span class="discount">-13%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/milk.png" alt="">
                <h3>natural milk</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price">₹ 55.50 <span> ₹ 60.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Milk">
                    <input type="hidden" name="product_price" value="55.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

            <div class="box">
                <span class="discount">-30%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/paneer.png" alt="">
                <h3>natural butter</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 400.50 <span> ₹ 180.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Butter">
                    <input type="hidden" name="product_price" value="400.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

            <div class="box">
                <span class="discount">-30%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/cheese.jpg" alt="">
                <h3>natural cheese</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 700.50 <span> ₹ 180.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Cheese">
                    <input type="hidden" name="product_price" value="700.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

        </div>

    </section>


    <section class="product" id="product">

        <h1 class="heading"><span> latest </span> dry fruit <span> products</span></h1>

        <div class="box-container">


            <div class="box">
                <span class="discount">-29%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/almond.png" alt="">
                <h3>natural almonts</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 800.50 <span> ₹ 900.20 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Almond">
                    <input type="hidden" name="product_price" value="800.50">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

            <div class="box">
                <span class="discount">-29%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/pista.png" alt="">
                <h3>natural pista</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 900.00 <span> ₹ 1250.00 </span> </div>
                <<form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Pista">
                    <input type="hidden" name="product_price" value="900.00">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                    </form>
            </div>

            <div class="box">
                <span class="discount">-29%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                </div>
                <img src="../img/angeer.jpg" alt="">
                <h3>natural angeer</h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <div class="price"> ₹ 1200.00 <span> ₹ 1500.00 </span> </div>
                <form action="cart_manage.php" method="post">
                    <input type="hidden" name="product_name" value="Angeer">
                    <input type="hidden" name="product_price" value="1200.00">
                    <button type="submit" class="btn" name="Add_to_cart">add to cart</button>
                </form>
            </div>

        </div>

    </section>

    <!-- <script>
    $(document).ready(function () {
        $(".btn").css("color", "white");
        $(".btn").css("cursor", "pointer");
        $(".btn").css(
            "background",
            "to right , rgb(255, 0, 247), rgba(38, 255, 0)"
        );
        
    });

    $(document).ready(function () {
        $(".btn").hover(function () {
            $(".btn").css(
            "background",
            "to right , rgb(255, 0, 247), rgba(38, 255, 0)"
        );
        });
    });
</script> -->
</body>

</html><?php /**PATH C:\xampp\htdocs\first_laravel_project\resources\views/category.blade.php ENDPATH**/ ?>