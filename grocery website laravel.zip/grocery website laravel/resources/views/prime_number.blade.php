<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>prime number</title>
</head>
<body>
@for($i=2; $i<=100; $i++)
      {
         $chk = 0;
         @for($j=2; $j<$i; $j++)
         {
            @if($i%$j==0)
            {
               $chk++;
               break;
            }
            @endif
         }
         @endfor
         @if($chk==0)
            {{$i}};
         @endif
      }
      @endfor
</body>
</html>