<header>
        <div class="header-1">
        <a href="{{url('/')}}" class="logo" style="text-decoration: none ; "><i class="fas fa-shopping-basket"></i>GroMart</a>
            <h1>login</h1>
        </div>
</header>