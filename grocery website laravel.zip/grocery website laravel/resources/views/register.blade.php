@include ('layouts.header');
<body>
    @include ('layouts.logo');
    <section class="contact" id="contact">

        <h1 class="heading"> <span>Register </span> here</h1>

        <form action="{{url('/')}}/register" method="post" id="myform">
            @csrf
            <div class="inputBox">
                <input id="name" type="text" name="user_name" placeholder="Enter Your Name">
                <label id="name_error">
                    @error('user_name')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <div class="inputBox">
                <input id="password" type="password" name="user_password" placeholder="Enter Password">
                <label id="password_error">
                    @error('user_password')
                    {{$message}}
                    @enderror
                </label>
            </div>

            <div class="inputBox">
                <input id="mobile" type="text" name="user_mobile" placeholder="Enter Your Mobile" maxlength="10">
                <label id="mobile_error">
                    @error('user_mobile')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <div class="inputBox">
                <input id="email" type="email" name="user_mail" placeholder="Enter Your Email">
                <label id="email_error">
                    @error('user_mail')
                    {{$message}}
                    @enderror
                </label>
            </div>

            <input type="submit" value="Sign Up" class="btn" style="margin : 8px;">
            <input type="reset" value="Reset" class="btn" style="margin: 8px;">

        </form>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Already account ? <a style="text-decoration: none;" href="{{'/login'}}"> Login </a></p>
        </div>
    </section>

    
</body>

</html>