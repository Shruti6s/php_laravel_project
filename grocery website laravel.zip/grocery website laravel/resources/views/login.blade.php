@include ('layouts.header');
<body>
    @include ('layouts.logo');
    <section class="contact" id="contact">

        <h1 class="heading"> <span>Login</span> here </h1>
        <form action="{{url('/')}}/login" id="myform" method="post">
            @csrf
            <div class="inputBox">
                <input type="text" id="mobile" name="user_mobile" placeholder="mobile">
                <label id="mobile_error">
                    @error('user_mobile')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <div class="inputBox">
                <input type="password" id="password" name="user_password" placeholder="password">
                <label id="password_error">
                    @error('user_password')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <input type="submit" value="Login" class="btn">

        </form>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Forget Password ? <a style="text-decoration: none;" href="{{'/reset_password'}}"> Reset </a></p>
        </div>
        <div class="container">
            <p class="mytext" align="center" style="font-size:15px;">Create New Account ? <a style="text-decoration: none;" href="{{'/register'}}"> Register </a></p>
        </div>
    </section>

</body>

</html>