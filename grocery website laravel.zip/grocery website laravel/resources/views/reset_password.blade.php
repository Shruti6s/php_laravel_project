@include ('layouts.header');
<body>
    @include ('layouts.logo');
    <section class="contact" id="contact">

        <h1 class="heading"> <span>Reset</span> Password </h1>

        <form action="{{url('/')}}/reset_password" id="myform" method="post">
            @csrf
            <div class="inputBox">
                <input type="text" id="mobile" name="user_mobile" placeholder="Mobile">
                <label id="mobile_error">
                    @error('user_mobile')
                    {{$message}}
                    @enderror
                </label>
            </div>

            <div class="inputBox">
                <input type="password" id="password" name="user_password" placeholder="Password">
                <label id="password_error">
                    @error('user_password')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <div class="inputBox">
                <input type="password" id="repassword" name="user_repassword" placeholder="Final Password">
                <label id="repassword_error">
                    @error('user_repassword')
                    {{$message}}
                    @enderror
                </label>
            </div>
            <input type="submit" value="Reset Password" class="btn">
        </form>
    </section>
</body>
</html>