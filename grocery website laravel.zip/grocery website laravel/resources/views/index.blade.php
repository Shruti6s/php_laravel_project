<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Growmart | Welcome</title>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .btn {
            display: inline-block;
            margin-top: 1rem;
            background: linear-gradient(to right, rgb(45, 180, 27), #2c2c54);
            color: #fff;
            border-radius: 20px 0 20px 0;
            padding: .8rem 3rem;
            font-size: 1.7rem;
            text-align: center;
            cursor: pointer;
        }

        .btn:hover {
            transition: all .9s linear;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.6);
            border-radius: 0 20px 0 20px;
        }
    </style>
</head>

<body>
    <!-- header section starts  -->
    
    <header>
        <div class="header-1">
            <!-- <a href="index.html" class="logo">GroMart</a> -->
            <a href="{{url('/')}}" class="logo"><i class="fas fa-shopping-basket"></i>GroMart</a>

            <form action="" class="search-box-container">
                <input type="search" id="search-box" placeholder="search here" />
                <label for="search-box" class="fas fa-search"></label>
            </form>
        </div>
        <div class="header-2">
            <div id="menu-bar" class="fas fa-bars"></div>

            <nav class="navbar">
                <a href="#home">home</a>
                <a href="#offers">offers</a>
                <a href="#category">category</a>
                <a href="register">register</a>
                <a href="{{'/login'}}" target="_blank">login</a>
            </nav>

            <div class="icons">
                <a href="shopping_item.php" class="fas fa-shopping-cart"></a>
                <a href="#" style="font-size:25px; text-transform: lowercase; ">
                {{ session('user_mobile') }}
                </a>
            </div>
        </div>
    </header>

    <section class="home" id="home">


        <div class="image">
            <img src="../img/food_banner.jpg" alt="">
        </div>

        <div class="content">
            <span>fresh and organic</span>
            <h3>your health is our responsblity</h3>
            <a href="{{'/register'}}" target="_blank" class="btn">get started</a>
        </div>
    </section>


    <h1 class="heading" align="center">Special <span>offers</span></h1>
    <section class="banner-container" id="offers">
        <div class="banner">
            <img src="../img/banner-2.jpg" alt="">
            <div class="content">
                <h3>special offer</h3>
                <p>upto 45% off</p>
                <a href="#" class="btn">check out</a>
            </div>
        </div>

        <div class="banner">
            <img src="../img/banner-3.jpg" alt="">
            <div class="content">
                <h3>limited offer</h3>
                <p>upto 50% off</p>
                <a href="#" class="btn">check out</a>
            </div>
        </div>

    </section>

    <section class="category" id="category">
        <h1 class="heading">shop by <span>category</span></h1>

        <div class="box-container">
            <div class="box">
                <h3>vegitables</h3>
                <p>upto 50% off</p>
                <img src="../img/all_vegetable.png">
                <a href="{{'/category'}}" target="_blank" class="btn">shop now</a>
            </div>
            <div class="box">
                <h3>fruit</h3>
                <p>upto 44% off</p>
                <img src="../img/all_fruite.png">
                <a href="{{'/category'}}" target="_blank" class="btn">shop now</a>
            </div>
            <div class="box">
                <h3>Dryfruit</h3>
                <p>upto 35% off</p>
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlz4lhuC1RrFv43vwy8HJr78m_EwmYy45QGw&usqp=CAU" , height="145">
                <a href="{{'/category'}}" target="_blank" class="btn">shop now</a>
            </div>
            <div class="box">
                <h3>milk product</h3>
                <p>upto 12% off</p>
                <img src="../img/milk_product.png" alt="">
                <a href="{{'/category'}}" target="_blank" class="btn">shop now</a>
            </div>
        </div>
    </section>


</body>

</html>